# GitBook Worker v2.9.1 Customer Acceptance Evidence

This archive contains redacted customer acceptance evidence for GitBook Worker v2.9.1.

Privacy boundary:

- No customer PDF is included.
- No customer Markdown/source text is included.
- No extracted customer text, raw metrics report, CSV, SARIF, HTML report, log dump, or page snapshot is included.
- Only aggregate counts, release verification notes, and privacy statements are included.

The full diagnostic inputs and generated customer artifacts stayed in ignored local paths during release preparation.
