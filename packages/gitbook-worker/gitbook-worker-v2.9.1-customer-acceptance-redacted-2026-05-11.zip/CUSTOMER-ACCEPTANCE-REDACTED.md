# Customer Acceptance Summary - Redacted

Release: GitBook Worker v2.9.1 "Abnahmefix"
Date: 2026-05-11
Profile: release
Run path: orchestrated customer editorial-quality step
Status: passed_with_warnings

## Customer Artifact Summary

| Metric | Value |
| --- | ---: |
| PDF build status | passed |
| PDF file size | 4,355,354 bytes |
| PDF pages | 868 |
| Portrait pages | 830 |
| Landscape pages | 38 |
| PDF TOC entries | 780 |
| Low-text pages (<= 15 text lines) | 144 |
| Very-low-text pages (<= 5 text lines) | 38 |
| Empty text pages | 1 |
| Text-layer extraction replacement signals | 9,317 |

## Editorial Acceptance Counts

| Severity | Count |
| --- | ---: |
| Blocked | 0 |
| Fail | 0 |
| Warn | 43 |
| Info | 7 |

## Rule Breakdown

| Rule | Severity | Count |
| --- | --- | ---: |
| markdown.long_token | warn | 35 |
| pdf.toc.outline_without_markdown_heading | info | 5 |
| markdown.review_marker | warn | 4 |
| pdf.text.script_sample | info | 1 |
| metadata.version_mismatch | warn | 1 |
| pdf.text.extraction_replacement | warn | 1 |
| publish.summary.orphaned_markdown | warn | 1 |
| references.ai.tasks_detected | info | 1 |
| pdf.text.empty_pages | warn | 1 |

## Release Tooling Notes

- Long visible URLs and DOI-style links are routed through breakable LaTeX URL rendering.
- Text-layer replacement signals are classified as extraction/accessibility warnings, not as visual font failures.
- The customer acceptance run finished without blocked or fail findings.
- Warnings remain visible for editorial follow-up; they are not hidden or auto-accepted.

## Privacy Statement

This archive intentionally excludes customer raw data. It contains no customer PDF, source Markdown, extracted text, detailed finding locations, log dumps, diagnostic snapshots, CSV/SARIF reports, or HTML reports. The values above are aggregate release evidence only.
