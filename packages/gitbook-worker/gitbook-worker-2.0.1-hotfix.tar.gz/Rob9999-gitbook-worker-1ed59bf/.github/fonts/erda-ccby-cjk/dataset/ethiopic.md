# Ethiopic (Ge'ez) Sample Text

Die folgende Mini-Stichprobe stellt sicher, dass alle in den Pandoc-Warnungen
genannten Zeichen im CC BY-Fallback enthalten sind.

## Abgedeckte Zeichen

- ቡ ድ ኑ በ መ ጣ እ ።

## Beispielsatz

ቡድ ኑ በመ ጣ እ ።

Lizenz: CC BY 4.0
