---
title: Citations & further reading
date: 2024-06-01
version: 1.0doc_type: bibliography
citation_style: "APA"---

# Citations & further reading

1. **United Nations Data Portal.** Accessed on 1 June 2024. https://data.un.org/
2. **World Bank Open Data.** Accessed on 1 June 2024. https://data.worldbank.org/
3. **World Meteorological Organization – Public Resources.** Accessed on 1 June 2024. https://public.wmo.int/en
4. **Smithsonian Open Access.** Accessed on 1 June 2024. https://www.si.edu/openaccess

References within the book use numbered footnotes to point consistently to this list.
