---
title: Dedication
doc_type: dedication
order: 5
---

We dedicate this book to everyone who shares knowledge generously.
