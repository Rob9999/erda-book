---
title: Translator's Note
doc_type: translators-note
order: 6
---

This edition adapts the source text with care for clarity and consistency.
