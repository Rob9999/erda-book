---
title: Widmung
doc_type: dedication
order: 5
---

Wir widmen dieses Buch allen Mitwirkenden, die Wissen teilen.
