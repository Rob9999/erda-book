---
title: Hinweis der Übersetzung
doc_type: translators-note
order: 6
---

Diese Ausgabe basiert auf der englischen Fassung und wurde mit größter Sorgfalt übertragen.
