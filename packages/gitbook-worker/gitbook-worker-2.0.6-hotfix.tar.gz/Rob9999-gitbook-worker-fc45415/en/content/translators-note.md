---
title: Translator's Note
doc_type: translators-note
order: 6
---

# Translator's Note

This edition is based on the German version and was translated with the utmost care.
