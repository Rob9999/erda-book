---
doc_type: epilog
title: Epilogue
version: 1.0.0
---

# Epilogue

Placeholder for the epilogue / afterword.
