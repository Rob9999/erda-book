---
title: List of Abbreviations
doc_type: list-of-abbreviations
order: 7
---

- API – Application Programming Interface
- CLI – Command Line Interface
