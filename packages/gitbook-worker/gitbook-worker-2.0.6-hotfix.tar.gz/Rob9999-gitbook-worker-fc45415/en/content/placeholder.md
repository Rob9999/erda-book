---
title: Content Note
date: 2024-06-01
version: 1.0
doc_type: placeholder
show_in_summary: false
---

# Content note

The content folder now contains complete sample chapters, appendices, images and templates. Use [content/index.md](./index.md) as your starting point.
