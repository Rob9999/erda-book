---
title: Dedication
doc_type: dedication
order: 5
---

# Dedication

We dedicate this book to everyone who shares knowledge generously.
