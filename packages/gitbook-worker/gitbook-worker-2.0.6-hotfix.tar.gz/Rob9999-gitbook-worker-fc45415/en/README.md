# English Edition

This folder contains the British English version of the ERDA book structure.

- Content lives in `content/` (start at `content/index.md`).
- Navigation is defined by `content/SUMMARY.md`.
- Build configuration is in `publish.yml`.

See `docs/multilingual-content-guide.md` for instructions on maintaining language trees.
