"""
ERDA Workflow Tools - Proof of Concept

This is a minimal example demonstrating the standalone package structure.
In the full implementation, this would contain the entire gitbook_worker.tools codebase.
"""

__version__ = "0.1.0"
__author__ = "ERDA Book Project"
__license__ = "MIT"

__all__ = ["hello", "__version__"]
