---
title: Inhaltshinweis
date: 2024-06-01
version: 1.0
doc_type: placeholder
show_in_summary: false
---

# Inhaltshinweis

Der Content-Ordner enthält jetzt vollständige Beispielkapitel, Anhänge, Bilddateien und Vorlagen. Verwende [content/index.md](./index.md) als Startpunkt.
