"""Command line entry point for the workflow orchestrator."""

from __future__ import annotations

from .orchestrator import main

if __name__ == "__main__":
    main()
