# Helper Tools

Dieses Verzeichnis enth�lt Hilfs-Skripte f�r Entwicklung, Debugging und Wartung.

## Verf�gbare Tools

- **find_utf8_issue.py**: Scannt Markdown-Dateien nach ung�ltigen UTF-8-Sequenzen
- **tools_import_test.py**: Testet Python-Modul-Importe

## Verwendung

Diese Tools sind f�r Entwickler gedacht und werden nicht im regul�ren Build-Prozess verwendet.
