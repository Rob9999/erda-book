# Emoji Farbe Test

Hier ist ein farbiges Emoji 😄 und eine Rakete 🚀.
