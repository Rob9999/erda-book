# gbw-latex-f8ywch55
