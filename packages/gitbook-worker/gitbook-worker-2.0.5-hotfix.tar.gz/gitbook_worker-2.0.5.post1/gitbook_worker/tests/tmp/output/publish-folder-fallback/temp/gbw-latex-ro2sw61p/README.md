# gbw-latex-ro2sw61p
