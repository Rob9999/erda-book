---
geometry:
- paperwidth=210mm
- paperheight=297mm
- left=15mm
- right=15mm
- top=15mm
- bottom=15mm
header-includes:
- \usepackage{calc}
- \usepackage{enumitem}
- \setlistdepth{20}
- \usepackage{longtable}
- \usepackage{ltablex}
- \usepackage{booktabs}
- \usepackage{array}
- \keepXColumns
- \setlength\LTleft{0pt}
- \setlength\LTright{0pt}
---

<a id="md-readme"></a>
## Test Project A

Dies ist **Project A** aus dem Multi-GitBook-Test-Szenario.

### Zweck

Dieses Projekt testet:
- Mehrere GitBooks in einem Repository
- Separate `book.json` für jedes Projekt
- Separate `content/` Verzeichnisse
- Unabhängige PDF-Generierung

### Eigenschaften von Project A

- Fokus: **Backend-Komponenten**
- Technologie: Python & FastAPI
- Status: In Entwicklung


\newpage

<a id="md-scenario-2-multi-gitbook-project-a-readme"></a>
## project-a


\newpage

<a id="md-summary"></a>
## Summary

* [Einführung](#md-readme)
* [Kapitel 1: Backend Architecture](#md-chapter-1-architecture)
* [Kapitel 2: API Design](#md-chapter-2-api)


\newpage

<a id="md-chapter-1-architecture"></a>
## Kapitel 1: Backend Architecture

### 1.1 Überblick

Die Backend-Architektur basiert auf einem modularen Ansatz:

- **API Layer**: FastAPI für RESTful endpoints
- **Business Logic**: Domain-driven Design
- **Data Layer**: PostgreSQL & Redis

### 1.2 Komponenten

```python
# Beispiel: FastAPI Endpoint
from fastapi import FastAPI, HTTPException

app = FastAPI()

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "project-a"}
```

### 1.3 Design-Prinzipien

| Prinzip | Beschreibung | Priorität |
|---------|-------------|-----------|
| SOLID | Clean Code Patterns | Hoch |
| DRY | Don't Repeat Yourself | Hoch |
| KISS | Keep It Simple | Mittel |

### 1.4 Mathematische Komplexität

Die Zeitkomplexität unserer Hauptalgorithmen:

$$
O(n \log n) \text{ für Sortierung}
$$

$$
O(1) \text{ für Cache-Zugriff}
$$


\newpage

<a id="md-chapter-2-api"></a>
## Kapitel 2: API Design

### 2.1 RESTful Endpoints

Unsere API folgt REST-Prinzipien:

- `GET /api/v1/users` - Liste aller User
- `POST /api/v1/users` - Neuen User erstellen
- `PUT /api/v1/users/{id}` - User aktualisieren
- `DELETE /api/v1/users/{id}` - User löschen

### 2.2 Request & Response

Beispiel Request Body:

```json
{
  "username": "test_user",
  "email": "test@example.com",
  "role": "admin"
}
```

### 2.3 Error Handling

Fehlerbehandlung mit HTTP Status Codes:

- **200 OK** ✅ - Erfolg
- **400 Bad Request** ⚠️ - Validierungsfehler
- **401 Unauthorized** 🔒 - Authentifizierung fehlgeschlagen
- **404 Not Found** ❌ - Ressource nicht gefunden
- **500 Internal Server Error** 💥 - Server-Fehler

### 2.4 Performance-Metriken

Durchschnittliche Response-Zeiten:

$$
\text{Latenz} = \frac{\sum_{i=1}^{n} t_i}{n} \approx 50\text{ms}
$$

Wo $t_i$ die individuelle Request-Zeit ist.
