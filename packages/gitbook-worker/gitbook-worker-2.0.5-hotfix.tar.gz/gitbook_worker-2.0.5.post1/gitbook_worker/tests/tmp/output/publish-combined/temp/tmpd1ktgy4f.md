---
geometry:
- paperwidth=210mm
- paperheight=297mm
- left=15mm
- right=15mm
- top=15mm
- bottom=15mm
header-includes:
- \usepackage{calc}
- \usepackage{enumitem}
- \setlistdepth{20}
- \usepackage{longtable}
- \usepackage{ltablex}
- \usepackage{booktabs}
- \usepackage{array}
- \keepXColumns
- \setlength\LTleft{0pt}
- \setlength\LTright{0pt}
---

<a id="md-readme"></a>
# Test GitBook

Dies ist ein Test-GitBook für Integrationstests. Es demonstriert die grundlegende GitBook-Struktur mit SUMMARY.md und book.json.

## Zweck

Dieses minimale GitBook testet:
- Korrekte Auswertung von `book.json` (insbesondere `root: content/`)
- Korrektes Einlesen von `SUMMARY.md`
- Kombination mehrerer Markdown-Dateien
- PDF-Generierung mit Pandoc/LaTeX

## Struktur

Das GitBook enthält:
- README.md (diese Datei)
- SUMMARY.md (Inhaltsverzeichnis)
- Kapitel 1: Einführung
- Kapitel 2: Hauptteil mit speziellen Zeichen
- Kapitel 3: Zusammenfassung


\newpage

<a id="md-data-scenario-1-single-gitbook-readme"></a>
# scenario-1-single-gitbook


\newpage

<a id="md-summary"></a>
# Summary

* [Einführung](#md-readme)
* [Kapitel 1: Grundlagen](#md-chapter-1-grundlagen)
* [Kapitel 2: Spezielle Zeichen & Tests](#md-chapter-2-spezielle-zeichen)
* [Kapitel 3: Zusammenfassung](#md-chapter-3-zusammenfassung)


\newpage

<a id="md-chapter-1-grundlagen"></a>
# Kapitel 1: Grundlagen

Dies ist das erste Kapitel des Test-GitBooks.

## 1.1 Einleitung

Ein Test-GitBook sollte verschiedene Markdown-Features demonstrieren:

- Listen (ungeordnet)
- **Fettdruck**
- *Kursiv*
- `Code inline`

## 1.2 Code-Block

```python
def hello_world():
    print("Hello from test GitBook!")
    return True
```

## 1.3 Tabelle

| Spalte 1 | Spalte 2 | Spalte 3 |
|----------|----------|----------|
| Wert A   | Wert B   | Wert C   |
| Wert D   | Wert E   | Wert F   |

## 1.4 Mathematik

Die Formel $E = mc^2$ ist bekannt. Komplexere Formeln:

$$
\int_0^\infty e^{-x^2} dx = \frac{\sqrt{\pi}}{2}
$$


\newpage

<a id="md-chapter-2-spezielle-zeichen"></a>
# Kapitel 2: Spezielle Zeichen & Tests

Dieses Kapitel testet LaTeX-Sonderzeichen und Emoji-Support.

## 2.1 LaTeX-Sonderzeichen im Titel & Text

Folgende Zeichen müssen korrekt escaped werden:
- Ampersand: A & B (sollte funktionieren)
- Prozent: 100% Erfolg  
- Dollar: \$100 (ohne Math-Mode)
- Unterstrich: test\_variable
- Hash: \#hashtag
- Geschweifte Klammern: \{test\}
- Backslash: `C:\Pfad\Test` C:\\Pfad\\Test und (in Code, da Backslash speziell)

## 2.2 Emoji-Tests

Verschiedene Emojis sollten korrekt dargestellt werden:

- 😀 Lachen
- 🎉 Party
- ✅ Erledigt
- 🇩🇪 Deutsche Flagge
- 🇪🇺 EU-Flagge

## 2.3 CJK-Zeichen

Test für CJK-Font-Fallback:

- 中文 (Chinesisch)
- 日本語 (Japanisch)
- 한국어 (Koreanisch)

## 2.4 Komplexe Kombination

Ein Satz mit allem: Die EU 🇪🇺 erreichte 2025 100% Erfolg bei A & B mit $1000 Budget! 中文支持 ✅


\newpage

<a id="md-chapter-3-zusammenfassung"></a>
# Kapitel 3: Zusammenfassung

## 3.1 Fazit

Dieses Test-GitBook hat erfolgreich demonstriert:

1. ✅ Korrekte Verarbeitung von `book.json` mit `root: content/`
2. ✅ Einlesen und Verarbeiten von `SUMMARY.md`
3. ✅ Kombination mehrerer Markdown-Dateien mit `\newpage`
4. ✅ Korrekte Behandlung von LaTeX-Sonderzeichen (& % $ # _ { } \)
5. ✅ Emoji-Rendering mit Twemoji
6. ✅ CJK-Font-Fallback für chinesische, japanische und koreanische Zeichen

## 3.2 Testabdeckung

Dieses Szenario deckt ab:
- **Single GitBook**: Ein einzelnes GitBook-Projekt
- **book.json**: Mit `root` Property
- **SUMMARY.md**: Definiertes Inhaltsverzeichnis
- **Spezialzeichen**: LaTeX-kritische Zeichen im Titel und Content
- **Emoji**: Standard- und Flaggen-Emojis
- **CJK**: Multiscript-Support

## 3.3 Erwartetes Ergebnis

Der PDF-Build sollte erfolgreich sein:
- ✅ Exit Code 0
- ✅ PDF erstellt unter `output/test-gitbook.pdf`
- ✅ Combined Markdown unter `output/test-gitbook.md` (wenn `keep_combined: true`)
- ✅ Keine YAML-Parse-Fehler
- ✅ Keine LaTeX-Kompilierungsfehler
