---
geometry:
- paperwidth=210mm
- paperheight=297mm
- left=15mm
- right=15mm
- top=15mm
- bottom=15mm
header-includes:
- \usepackage{calc}
- \usepackage{enumitem}
- \setlistdepth{20}
- \usepackage{longtable}
- \usepackage{ltablex}
- \usepackage{booktabs}
- \usepackage{array}
- \keepXColumns
- \setlength\LTleft{0pt}
- \setlength\LTright{0pt}
---

<a id="md-readme"></a>
## Test Project B

Dies ist **Project B** aus dem Multi-GitBook-Test-Szenario.

### Zweck

Dieses Projekt testet:
- Koexistenz mit Project A
- Separate Konfiguration und Struktur
- Unabhängige Inhalte und Themen
- Parallele PDF-Generierung

### Eigenschaften von Project B

- Fokus: **Frontend-Komponenten**
- Technologie: React & TypeScript
- Status: Produktionsreif 🚀


\newpage

<a id="md-scenario-2-multi-gitbook-project-b-readme"></a>
## project-b


\newpage

<a id="md-summary"></a>
## Summary

* [Einführung](#md-readme)
* [Kapitel 1: Component Library](#md-chapter-1-components)
* [Kapitel 2: State Management](#md-chapter-2-state)


\newpage

<a id="md-chapter-1-components"></a>
## Kapitel 1: Component Library

### 1.1 Überblick

Unsere React Component Library bietet:

- **Buttons**: Primary, Secondary, Ghost
- **Forms**: Input, Select, Checkbox, Radio
- **Layout**: Container, Grid, Flex
- **Navigation**: Navbar, Sidebar, Breadcrumb

### 1.2 Beispiel: Button Component

```typescript
import React from 'react';

interface ButtonProps {
  variant: 'primary' | 'secondary' | 'ghost';
  onClick: () => void;
  children: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({ 
  variant, 
  onClick, 
  children 
}) => {
  return (
    <button 
      className={`btn btn-${variant}`}
      onClick={onClick}
    >
      {children}
    </button>
  );
};
```

### 1.3 Component-Katalog

| Component | Variants | Status |
|-----------|----------|--------|
| Button | 3 | ✅ Stabil |
| Input | 5 | ✅ Stabil |
| Modal | 2 | 🚧 Beta |
| Toast | 4 | ✅ Stabil |

### 1.4 Accessibility

Alle Komponenten erfüllen **WCAG 2.1 Level AA** Standards:

- Keyboard-Navigation ⌨️
- Screen-Reader Support 🔊
- Color-Contrast-Ratio ≥ 4.5:1


\newpage

<a id="md-chapter-2-state"></a>
## Kapitel 2: State Management

### 2.1 Redux Toolkit

Wir verwenden **Redux Toolkit** für globales State Management:

```typescript
import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface UserState {
  currentUser: User | null;
  isAuthenticated: boolean;
}

const initialState: UserState = {
  currentUser: null,
  isAuthenticated: false,
};

export const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    login: (state, action: PayloadAction<User>) => {
      state.currentUser = action.payload;
      state.isAuthenticated = true;
    },
    logout: (state) => {
      state.currentUser = null;
      state.isAuthenticated = false;
    },
  },
});
```

### 2.2 State-Hierarchie

```
Root State
├── user: UserState
├── products: ProductState
├── cart: CartState
└── ui: UIState
```

### 2.3 Performance-Optimierung

Memoization mit React.memo und useMemo:

- **React.memo**: Verhindert unnötige Re-Renders
- **useMemo**: Cached berechnete Werte
- **useCallback**: Cached Callback-Funktionen

### 2.4 Best Practices

1. ✅ Immutable State Updates (mit Immer)
2. ✅ Normalized State Shape
3. ✅ Action Creators mit TypeScript
4. ✅ Selektoren für komplexe Queries

### 2.5 Testing

Test-Coverage für State Management:

$$
\text{Coverage} = \frac{\text{Getestete Actions}}{\text{Gesamt Actions}} \times 100\% = 95\%
$$

🎯 Ziel: 100% Coverage für kritische Flows
