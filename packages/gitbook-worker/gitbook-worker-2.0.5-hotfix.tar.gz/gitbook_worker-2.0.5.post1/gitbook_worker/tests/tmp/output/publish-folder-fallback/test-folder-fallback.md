---
geometry:
- paperwidth=210mm
- paperheight=297mm
- left=15mm
- right=15mm
- top=15mm
- bottom=15mm
header-includes:
- \usepackage{calc}
- \usepackage{enumitem}
- \setlistdepth{20}
- \usepackage{longtable}
- \usepackage{ltablex}
- \usepackage{booktabs}
- \usepackage{array}
- \keepXColumns
- \setlength\LTleft{0pt}
- \setlength\LTright{0pt}
---

<a id="md-scenario-4-folder-without-gitbook-docs-readme"></a>
## Documentation Overview

Dies ist ein Ordner ohne GitBook-Struktur (kein `book.json`, kein `SUMMARY.md`).

### Purpose

Dieses Szenario testet den **Fallback-Modus** des Publishers:

- Automatisches Sammeln aller `.md` Dateien
- Sortierung nach Dateinamen
- README.md wird priorisiert (wenn vorhanden)
- Keine explizite Reihenfolge definiert

### Expected Behavior

Der Publisher sollte:

1. ✅ Alle `.md` Dateien im Ordner finden
2. ✅ README.md an erste Stelle setzen
3. ✅ Andere Dateien alphabetisch sortieren
4. ✅ PDF ohne SUMMARY-Struktur generieren
5. ✅ Seitenumbrüche zwischen Dateien einfügen


\newpage

<a id="md-scenario-4-folder-without-gitbook-docs-01-getting-started"></a>
## Getting Started

### Installation

Um das System zu installieren, führen Sie folgende Schritte aus:

```bash
# Clone das Repository
git clone https://example.com/repo.git

# Installiere Dependencies
npm install

# Starte den Development Server
npm run dev
```

### Configuration

Erstellen Sie eine `.env` Datei:

```
API_KEY=your_key_here
DATABASE_URL=postgresql://localhost:5432/mydb
PORT=3000
```

### First Steps

1. Registrieren Sie einen Account
2. Erstellen Sie ein neues Projekt
3. Konfigurieren Sie die Einstellungen
4. Starten Sie mit der Entwicklung

### Mehrsprachiger Support

Das System unterstützt verschiedene Sprachen:

- **Deutsch**: Vollständig unterstützt 🇩🇪
- **English**: Fully supported 🇬🇧
- **日本語**: 完全対応 🇯🇵
- **中文**: 完全支持 🇨🇳

### Common Issues

| Problem | Lösung | Priorität |
|---------|--------|-----------|
| Port besetzt | Anderen Port verwenden | Mittel |
| DB-Verbindung fehlgeschlagen | Credentials prüfen | Hoch |
| Build-Fehler | `npm clean-install` | Niedrig |


\newpage

<a id="md-scenario-4-folder-without-gitbook-docs-02-api-reference"></a>
## API Reference

### REST Endpoints

#### Users API

##### GET /api/users

Alle Benutzer abrufen.

**Response:**

```json
{
  "users": [
    {
      "id": 1,
      "username": "admin",
      "email": "admin@example.com",
      "role": "admin"
    }
  ],
  "total": 1
}
```

##### POST /api/users

Neuen Benutzer erstellen.

**Request Body:**

```json
{
  "username": "newuser",
  "email": "user@example.com",
  "password": "secureP@ssw0rd",
  "role": "user"
}
```

**Response:**

```json
{
  "id": 2,
  "username": "newuser",
  "email": "user@example.com",
  "role": "user",
  "created_at": "2024-01-15T10:30:00Z"
}
```

#### Products API

##### GET /api/products

Liste aller Produkte mit Paginierung.

**Query Parameters:**

| Parameter | Typ | Beschreibung | Default |
|-----------|-----|--------------|---------|
| page | integer | Seitennummer | 1 |
| limit | integer | Einträge pro Seite | 10 |
| sort | string | Sortierfeld | name |
| order | string | asc oder desc | asc |

**Response:**

```json
{
  "products": [
    {
      "id": 1,
      "name": "Product A",
      "price": 29.99,
      "stock": 100
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 150,
    "pages": 15
  }
}
```

### Error Codes

| Code | Status | Beschreibung |
|------|--------|--------------|
| 200 | OK | Erfolg ✅ |
| 201 | Created | Erstellt ✅ |
| 400 | Bad Request | Ungültige Eingabe ❌ |
| 401 | Unauthorized | Nicht authentifiziert 🔒 |
| 403 | Forbidden | Keine Berechtigung 🚫 |
| 404 | Not Found | Nicht gefunden ❓ |
| 500 | Internal Error | Server-Fehler 💥 |

### Rate Limiting

API-Anfragen sind limitiert:

$$
\text{Limit} = \begin{cases}
1000 \text{ req/h} & \text{Free Tier} \\
10000 \text{ req/h} & \text{Pro Tier} \\
\infty & \text{Enterprise}
\end{cases}
$$

### Authentication

Bearer Token in Authorization Header:

```http
GET /api/users HTTP/1.1
Host: api.example.com
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
Content-Type: application/json
```

### WebSocket Events

Echtzeit-Kommunikation über WebSocket:

```javascript
const ws = new WebSocket('wss://api.example.com/ws');

ws.on('message', (data) => {
    console.log('Received:', data);
});

// Sende Nachricht
ws.send(JSON.stringify({
    type: 'subscribe',
    channels: ['orders', 'notifications']
}));
```

#### Verfügbare Events

| Event | Direction | Beschreibung |
|-------|-----------|--------------|
| subscribe | Client → Server | Kanal abonnieren |
| unsubscribe | Client → Server | Kanal abbestellen |
| message | Server → Client | Neue Nachricht |
| error | Server → Client | Fehler aufgetreten |
| ping | Bidirectional | Keep-Alive |

### Internationalisierung

Die API unterstützt mehrere Sprachen über `Accept-Language` Header:

```http
Accept-Language: de-DE, en-US, ja-JP, zh-CN
```

Beispiel-Antworten:

- **Deutsch**: "Benutzer erfolgreich erstellt"
- **English**: "User created successfully"
- **日本語**: "ユーザーが正常に作成されました"
- **中文**: "用户创建成功"


\newpage

<a id="md-scenario-4-folder-without-gitbook-docs-03-advanced-topics"></a>
## Advanced Topics

### Performance Optimization

#### Database Indexing

Optimale Index-Strategien für verschiedene Abfragen:

| Query Type | Index | Performance Gain |
|------------|-------|------------------|
| Exact Match | B-Tree | 100x - 1000x |
| Range Query | B-Tree | 10x - 100x |
| Full-Text | GIN/GiST | 50x - 500x |
| Geospatial | GiST | 100x - 10000x |

**Beispiel:**

```sql
-- B-Tree Index für schnelle Lookups
CREATE INDEX idx_users_email ON users(email);

-- GIN Index für Volltextsuche
CREATE INDEX idx_posts_content ON posts USING gin(to_tsvector('german', content));

-- Composite Index für Multi-Column Queries
CREATE INDEX idx_orders_user_date ON orders(user_id, created_at DESC);
```

#### Caching Strategy

Multi-Layer Caching für optimale Performance:

```
┌─────────────┐
│   Browser   │  (Service Worker, 24h)
└──────┬──────┘
       ↓
┌─────────────┐
│     CDN     │  (CloudFront, 1h)
└──────┬──────┘
       ↓
┌─────────────┐
│    Redis    │  (In-Memory, 5min)
└──────┬──────┘
       ↓
┌─────────────┐
│  Database   │  (PostgreSQL)
└─────────────┘
```

**Cache-Hit-Ratio Formel:**

$$
\text{Hit Ratio} = \frac{\text{Cache Hits}}{\text{Total Requests}} \times 100\%
$$

Ziel: > 95% für optimale Performance

#### Load Balancing

Anfragen werden auf mehrere Server verteilt:

| Algorithmus | Use Case | Fairness |
|-------------|----------|----------|
| Round Robin | Gleichmäßige Last | ⭐⭐⭐⭐⭐ |
| Least Connections | Ungleiche Requests | ⭐⭐⭐⭐ |
| IP Hash | Session Affinity | ⭐⭐⭐ |
| Weighted | Heterogene Server | ⭐⭐⭐⭐ |

### Security Best Practices

#### Input Validation

**Immer validieren:**

```python
import re
from typing import Optional

def validate_email(email: str) -> Optional[str]:
    """Validate email address with Unicode support."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if re.match(pattern, email):
        return email.lower()
    return None

# Test mit internationalen Domains
emails = [
    'user@example.com',
    'admin@例え.jp',  # Internationalized Domain Names
    'test@münchen.de'
]
```

#### SQL Injection Prevention

**❌ Unsicher:**

```python
query = f"SELECT * FROM users WHERE email = '{user_input}'"
```

**✅ Sicher:**

```python
query = "SELECT * FROM users WHERE email = %s"
cursor.execute(query, (user_input,))
```

#### XSS Protection

Output-Encoding für verschiedene Kontexte:

| Context | Encoding | Beispiel |
|---------|----------|----------|
| HTML Body | HTML Entity | `\&lt;script\&gt;` |
| HTML Attribute | Attribute | `\&quot;onclick=...\&quot;` |
| JavaScript | Unicode | `\u003cscript\u003e` |
| URL | Percent | `\%3Cscript\%3E` |

### Microservices Architecture

Verteilte System-Architektur:

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   API        │────▶│   Auth       │────▶│   Users      │
│   Gateway    │     │   Service    │     │   Service    │
└──────┬───────┘     └──────────────┘     └──────────────┘
       │
       ├────────────▶ ┌──────────────┐     ┌──────────────┐
       │              │   Product    │────▶│   Inventory  │
       │              │   Service    │     │   Service    │
       │              └──────────────┘     └──────────────┘
       │
       └────────────▶ ┌──────────────┐     ┌──────────────┐
                      │   Order      │────▶│   Payment    │
                      │   Service    │     │   Service    │
                      └──────────────┘     └──────────────┘
```

#### Service Communication

**Synchronous (REST):**

```javascript
// TypeScript Example
async function getUserProfile(userId: string): Promise<User> {
    const response = await fetch(`https://users-service/api/users/${userId}`);
    if (!response.ok) {
        throw new Error(`Failed to fetch user: ${response.status}`);
    }
    return response.json();
}
```

**Asynchronous (Message Queue):**

```python
import pika
import json

def publish_order_created(order_id: str, user_id: str):
    """發送訂單創建事件到消息隊列 (Sende Bestellung an Message Queue)"""
    connection = pika.BlockingConnection(pika.ConnectionParameters('rabbitmq'))
    channel = connection.channel()
    
    message = {
        'event': 'order.created',
        'order_id': order_id,
        'user_id': user_id,
        'timestamp': '2024-01-15T10:30:00Z'
    }
    
    channel.basic_publish(
        exchange='orders',
        routing_key='order.created',
        body=json.dumps(message)
    )
    
    connection.close()
```

### Monitoring & Observability

#### Key Metrics

Die "Golden Signals" für Service Health:

| Metric | Description | Alert Threshold |
|--------|-------------|-----------------|
| **Latency** | Response Time | p95 > 500ms |
| **Traffic** | Requests/Second | > 10000 rps |
| **Errors** | Error Rate | > 1\% |
| **Saturation** | Resource Usage | CPU > 80\% |

#### Distributed Tracing

Trace-ID durch alle Services:

```
Request: GET /api/orders/123
├─ api-gateway (5ms)
│  └─ auth-service (10ms)
│     └─ users-service (15ms)
├─ orders-service (20ms)
│  ├─ database (50ms)
│  └─ cache (2ms)
└─ payment-service (100ms)
   └─ external-api (200ms)

Total: 402ms (Waterfall)
```

#### Alerting Rules

Prometheus Alert-Beispiele:

```yaml
groups:
  - name: api_alerts
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.05
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "High error rate detected"
          description: "Error rate is {{ $value | humanizePercentage }}"
```

### Internationalization (i18n)

Mehrsprachige Unterstützung in der Anwendung:

#### Sprachkonfiguration

```typescript
const translations = {
    de: {
        welcome: 'Willkommen',
        goodbye: 'Auf Wiedersehen'
    },
    en: {
        welcome: 'Welcome',
        goodbye: 'Goodbye'
    },
    ja: {
        welcome: 'ようこそ',
        goodbye: 'さようなら'
    },
    zh: {
        welcome: '欢迎',
        goodbye: '再见'
    },
    ko: {
        welcome: '환영합니다',
        goodbye: '안녕히 가세요'
    }
};
```

#### Datum & Zeit-Formatierung

| Locale | Format | Beispiel |
|--------|--------|----------|
| de-DE | DD.MM.YYYY HH:mm | 15.01.2024 14:30 |
| en-US | MM/DD/YYYY h:mm AM/PM | 01/15/2024 2:30 PM |
| ja-JP | YYYY年MM月DD日 HH:mm | 2024年01月15日 14:30 |
| zh-CN | YYYY-MM-DD HH:mm | 2024-01-15 14:30 |

#### Währungsformatierung

```javascript
const formatCurrency = (amount, locale, currency) => {
    return new Intl.NumberFormat(locale, {
        style: 'currency',
        currency: currency
    }).format(amount);
};

// Beispiele:
formatCurrency(1234.56, 'de-DE', 'EUR');  // 1.234,56 €
formatCurrency(1234.56, 'en-US', 'USD');  // $1,234.56
formatCurrency(1234.56, 'ja-JP', 'JPY');  // ¥1,235
```

### Deployment Strategies

#### Blue-Green Deployment

Null-Downtime Releases:

```
Current (Blue):  [v1.0] ──▶ 100% Traffic
New (Green):     [v2.0] ──▶   0% Traffic

          ↓ Switch

Old (Blue):      [v1.0] ──▶   0% Traffic
Current (Green): [v2.0] ──▶ 100% Traffic
```

#### Canary Releases

Graduelles Rollout:

| Phase | v1.0 Traffic | v2.0 Traffic | Duration |
|-------|--------------|--------------|----------|
| 1 | 95\% | 5\% | 1 hour |
| 2 | 80\% | 20\% | 2 hours |
| 3 | 50\% | 50\% | 4 hours |
| 4 | 0\% | 100\% | Final |

**Monitoring-Metriken während Canary:**

$$
\text{Success} = \frac{\text{Errors}_{v2.0}}{\text{Errors}_{v1.0}} < 1.2
$$

Falls die Fehlerrate von v2.0 mehr als 20% über v1.0 liegt → Rollback!

---

## Zusammenfassung

Diese fortgeschrittenen Themen decken ab:

- ✅ Performance-Optimierung (DB, Caching, Load Balancing)
- ✅ Security Best Practices (Validation, SQL Injection, XSS)
- ✅ Microservices-Architektur (Sync/Async Communication)
- ✅ Monitoring & Observability (Golden Signals, Tracing)
- ✅ Internationalisierung (8+ Sprachen)
- ✅ Deployment-Strategien (Blue-Green, Canary)
- ✅ Komplexe Tabellen & Diagramme
- ✅ Code mit Unicode-Kommentaren
- ✅ Mathematische Formeln
