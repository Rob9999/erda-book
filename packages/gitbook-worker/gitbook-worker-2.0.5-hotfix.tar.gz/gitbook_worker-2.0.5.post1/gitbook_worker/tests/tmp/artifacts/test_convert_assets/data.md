> Quelle: data.csv

| name   |   value |
|:-------|--------:|
| A      |       1 |
| B      |       2 |