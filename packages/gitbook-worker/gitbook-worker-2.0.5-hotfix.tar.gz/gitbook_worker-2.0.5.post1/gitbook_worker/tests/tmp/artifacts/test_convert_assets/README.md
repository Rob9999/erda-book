# test_convert_assets
