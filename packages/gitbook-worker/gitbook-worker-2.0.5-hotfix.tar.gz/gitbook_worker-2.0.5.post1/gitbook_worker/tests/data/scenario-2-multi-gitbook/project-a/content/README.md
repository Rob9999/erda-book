# Test Project A

Dies ist **Project A** aus dem Multi-GitBook-Test-Szenario.

## Zweck

Dieses Projekt testet:
- Mehrere GitBooks in einem Repository
- Separate `book.json` für jedes Projekt
- Separate `content/` Verzeichnisse
- Unabhängige PDF-Generierung

## Eigenschaften von Project A

- Fokus: **Backend-Komponenten**
- Technologie: Python & FastAPI
- Status: In Entwicklung
