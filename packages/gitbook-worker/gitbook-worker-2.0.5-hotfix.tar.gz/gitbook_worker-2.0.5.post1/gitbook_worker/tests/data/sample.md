# Sample Document

This is a sample document used for PDF integration tests.

| Item | Value |
| --- | --- |
| A | 1 |
| B | 2 |
