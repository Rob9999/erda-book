# Legacy GitBook Worker docs

This folder mirrors the historical `.github/gitbook_worker/` directory. The live
package and tooling now live at repository root (`gitbook_worker/`), so these files
are read-only references. Add new documentation to `docs/` or `gitbook_worker/docs/`
instead of extending the archive.
