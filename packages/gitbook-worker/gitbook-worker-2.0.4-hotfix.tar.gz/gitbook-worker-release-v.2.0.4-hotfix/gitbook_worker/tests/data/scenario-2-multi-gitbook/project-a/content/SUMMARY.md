# Summary

* [Einführung](README.md)
* [Kapitel 1: Backend Architecture](chapter-1-architecture.md)
* [Kapitel 2: API Design](chapter-2-api.md)
