---
doc_type: legal-notice
title: Rechtliche Hinweise
version: 1.0.0
---

# Rechtliche Hinweise

Platzhalter für Impressum oder rechtliche Hinweise.
