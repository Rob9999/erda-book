---
title: Hinweis der Übersetzung
doc_type: translators-note
order: 6
---

# Hinweis der Übersetzung

Diese Ausgabe basiert auf der deutschen Fassung und wurde mit größter Sorgfalt übertragen.
