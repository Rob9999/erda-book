---
doc_type: errata
title: Errata
version: 1.0.0
---

# Errata

Platzhalter für bekannte Fehler und Korrekturen.
