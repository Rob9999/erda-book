---
title: Widmung
doc_type: dedication
order: 5
---

# Widmung

Wir widmen dieses Buch allen Mitwirkenden, die Wissen teilen.
