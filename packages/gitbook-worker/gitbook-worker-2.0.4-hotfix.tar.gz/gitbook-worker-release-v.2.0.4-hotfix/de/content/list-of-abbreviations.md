---
title: Abkürzungsverzeichnis
doc_type: list-of-abbreviations
order: 7
---

# Abkürzungsverzeichnis

- API – Application Programming Interface
- CLI – Command Line Interface
