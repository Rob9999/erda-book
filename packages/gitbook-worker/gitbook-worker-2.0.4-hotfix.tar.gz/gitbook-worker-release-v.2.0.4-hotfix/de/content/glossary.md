---
doc_type: glossary
title: Glossar
version: 1.0.0
---

# Glossar

Platzhalter für Begriffe und Definitionen.
