---
title: Startseite (Navigation)
doc_type: placeholder
---

# Startseite

Willkommen! Diese Seite fasst die wichtigsten Einstiege zusammen:

- [Cover & Überblick](index.md)
- [Vorwort](preface.md) und [Inhaltshinweis](placeholder.md)
- [Kapitel 1 – Beobachtbare Muster](chapters/chapter-01.md)
- [Kapitel 2 – Vergleichstabellen](chapters/chapter-02.md)
- [Beispiel-Sammlungen (Emoji)](examples/README.md)
- [Anhänge & Nachschlagewerke](appendices/README.md)
- [Tabellen- und Abbildungsverzeichnisse](list-of-tables.md)

> Tipp: Nutze diese Seite als Navigation, falls du direkt in die Kapitel oder Beispiele springen willst.
