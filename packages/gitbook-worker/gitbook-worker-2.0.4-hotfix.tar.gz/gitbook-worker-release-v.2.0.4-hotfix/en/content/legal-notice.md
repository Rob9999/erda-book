---
doc_type: legal-notice
title: Legal Notice
version: 1.0.0
---

# Legal Notice

Placeholder for imprint and legal notes.
