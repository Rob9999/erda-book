---
title: Zitationen & weiterführende Quellen
date: 2024-06-01
version: 1.0
---

# Zitationen & weiterführende Quellen

1. **United Nations Data Portal.** Zugriff am 01.06.2024. https://data.un.org/
2. **World Bank Open Data.** Zugriff am 01.06.2024. https://data.worldbank.org/
3. **World Meteorological Organization – Public Resources.** Zugriff am 01.06.2024. https://public.wmo.int/en
4. **Smithsonian Open Access.** Zugriff am 01.06.2024. https://www.si.edu/openaccess

Verweise innerhalb des Buchs nutzen nummerierte Fußnoten, um konsistent auf diese Liste zu zeigen.
