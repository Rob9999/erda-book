# Inhaltshinweis

Der Content-Ordner enthält jetzt vollständige Beispielkapitel, Anhänge, Bilddateien und Vorlagen. Verwende [content/index.md](./index.md) als Startpunkt.
