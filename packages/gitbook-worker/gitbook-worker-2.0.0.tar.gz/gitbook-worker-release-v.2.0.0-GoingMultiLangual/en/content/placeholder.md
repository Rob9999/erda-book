# Content note

The content folder now contains complete sample chapters, appendices, images and templates. Use [content/index.md](./index.md) as your starting point.
