# Sprints

- [hex-architecture-overview.md](hex-architecture-overview.md) — track overview and guiding principles.
- [sprint-hex-architecture-01.md](sprint-hex-architecture-01.md) — Sprint 01 plan (hexagonal foundations).
