"""Tests for emoji tooling under the consolidated GitHub tooling suite."""
