# Test Project B

Dies ist **Project B** aus dem Multi-GitBook-Test-Szenario.

## Zweck

Dieses Projekt testet:
- Koexistenz mit Project A
- Separate Konfiguration und Struktur
- Unabhängige Inhalte und Themen
- Parallele PDF-Generierung

## Eigenschaften von Project B

- Fokus: **Frontend-Komponenten**
- Technologie: React & TypeScript
- Status: Produktionsreif 🚀
