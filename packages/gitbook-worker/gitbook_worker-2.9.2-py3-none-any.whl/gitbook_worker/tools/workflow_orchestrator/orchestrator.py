"""High-level orchestrator that mirrors the GitHub workflow chain.

The module glues together the existing helper scripts so the full publishing
pipeline can run either locally or inside GitHub Actions.  Profiles configured
in ``publish.yml`` decide which steps are executed and whether a pre-built
Docker image from GHCR should be used.
"""

from __future__ import annotations

import argparse
import datetime as _dt
import logging
import json
import os
import shlex
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from string import Template
from typing import Iterable, List, Mapping, MutableMapping, Sequence

import yaml

from gitbook_worker import __version__ as PACKAGE_VERSION
from gitbook_worker import gh_paths
from gitbook_worker.tools.logging_config import (
    get_log_directory,
    get_logger,
    reconfigure_root_logger,
)
from gitbook_worker.tools.exit_codes import add_exit_code_help, handle_exit_code_help
from gitbook_worker.tools.publishing.frontmatter_config import FrontMatterConfigLoader
from gitbook_worker.tools.publishing.readme_config import ReadmeConfigLoader
from gitbook_worker.tools.utils import git as git_utils
from gitbook_worker.tools.utils.language_context import resolve_language_context
from gitbook_worker.tools.utils.smart_manifest import (
    SmartManifestError,
    detect_repo_root,
    resolve_manifest,
)
from gitbook_worker.tools.utils.smart_content import ContentEntry, load_content_config
from gitbook_worker.tools.utils.smart_manage_publish_flags import set_publish_flags

LOGGER = get_logger(__name__)
TOOL_NAME = "gitbook-worker"
LICENSE_SHORT = "MIT (see LICENSE)"
COPYRIGHT = (
    "Copyright (c) 2025-2026 Robert Alexander Massinger, Munich, Bavaria, Germany."
)


def _command_line() -> str:
    """Return the current command line as a shell-quoted string."""
    return " ".join(shlex.quote(part) for part in sys.argv)


def _print_start_banner(silent: bool) -> None:
    """Emit a concise startup banner to stdout unless silenced."""
    if silent:
        return
    lines = [
        f"{TOOL_NAME} v{PACKAGE_VERSION}",
        COPYRIGHT,
        f"License: {LICENSE_SHORT}",
    ]
    print("\n".join(lines))


def _log_start_context(args: argparse.Namespace, config: OrchestratorConfig) -> None:
    """Log startup context (command line and key paths) for workflow.log."""
    LOGGER.info(
        "startup | tool=%s version=%s license=%s cwd=%s",
        TOOL_NAME,
        PACKAGE_VERSION,
        LICENSE_SHORT,
        os.getcwd(),
    )
    LOGGER.info("startup | cmd=%s", _command_line())
    LOGGER.info(
        "startup | paths runtime_root=%s manifest=%s logs=%s package_root=%s package_logs=%s",
        config.root,
        config.manifest,
        get_log_directory(),
        gh_paths.REPO_ROOT,
        gh_paths.GH_LOGS_DIR,
    )


def _log_run_configuration(config: OrchestratorConfig) -> None:
    """Log derived runtime configuration for traceability."""
    LOGGER.info(
        "config | root=%s manifest=%s profile=%s language=%s dry_run=%s",
        config.root,
        config.manifest,
        config.profile.name,
        config.language_id,
        config.dry_run,
    )
    LOGGER.info(
        "config | repo_visibility=%s repository=%s commit=%s base=%s reset_others=%s",
        config.repo_visibility,
        config.repository,
        config.commit,
        config.base,
        config.reset_others,
    )
    if config.steps_override:
        LOGGER.info("config | steps_override=%s", ",".join(config.steps_override))
    if config.publisher_args:
        LOGGER.info("config | publisher_args=%s", ",".join(config.publisher_args))


_DEFAULT_STEPS = (
    "check_if_to_publish",
    "ensure_readme",
    "update_citation",
    "converter",
    "engineering-document-formatter",
    "generate_attribution",
    "publisher",
)

_SKIP_DIRS = {
    ".git",
    ".github",
    ".venv",
    "__pycache__",
    "node_modules",
    "simulations",
}

README_FILENAMES = ("README.md", "readme.md", "Readme.md")


class FontSyncError(RuntimeError):
    """Raised when the orchestrator cannot prepare required fonts."""


def _font_sync_hint(root: Path, manifest: Path | None) -> str:
    target_manifest = manifest or (root / "publish.yml")
    try:
        manifest_arg = target_manifest.relative_to(root)
    except ValueError:
        manifest_arg = target_manifest
    return (
        "Font-Synchronisation fehlgeschlagen. Bitte führen Sie 'gitbook-worker-fonts"
        f" sync --manifest {manifest_arg} --search-path .github/fonts' aus und wiederholen"
        " Sie den Lauf."
    )


@dataclass(frozen=True)
class DockerSettings:
    """Docker related configuration for a profile."""

    use_registry: bool
    image: str | None
    cache: bool


@dataclass(frozen=True)
class OrchestratorProfile:
    """Resolved profile information loaded from ``publish.yml``."""

    name: str
    steps: tuple[str, ...]
    docker: DockerSettings
    description: str | None = None
    env: Mapping[str, str] | None = None


@dataclass(frozen=True)
class OrchestratorConfig:
    """Immutable runtime options for the orchestrator."""

    root: Path
    manifest: Path
    logs_dir: Path
    content_config_path: Path | None
    language_id: str
    content_entry: ContentEntry
    language_root: Path
    profile: OrchestratorProfile
    repo_visibility: str
    repository: str | None
    commit: str | None
    base: str | None
    reset_others: bool
    publisher_args: tuple[str, ...]
    dry_run: bool
    isolated: bool
    no_gitbook_rename: bool = False
    steps_override: tuple[str, ...] | None = None
    quality_profile: str = "release"
    quality_baseline: Path | None = None
    quality_accepted_findings: Path | None = None
    quality_gate: bool = False
    quality_scope: str = "current"


class RuntimeContext:
    """Mutable helper carrying derived runtime values."""

    def __init__(
        self, config: OrchestratorConfig, manifest_data: dict | None = None
    ) -> None:
        self.config = config
        self.root = config.root
        self.language_root = config.language_root
        self.language_id = config.language_id
        self.content_entry = config.content_entry
        self.python = sys.executable or "python"
        self._manifest_data = manifest_data or {}
        self._frontmatter_loader: FrontMatterConfigLoader | None = None
        self._readme_loader: ReadmeConfigLoader | None = None
        github_dir = self.root / ".github"
        package_dir = self.root / "gitbook_worker"
        legacy_worker_dir = github_dir / "gitbook_worker"
        worker_tools_dir = package_dir / "tools"
        legacy_tools_dir = legacy_worker_dir / "tools"
        package_install_root = Path(__file__).resolve().parents[2]
        package_source_root = package_install_root.parent
        package_install_tools = package_install_root / "tools"

        if worker_tools_dir.exists():
            self.tools_dir = worker_tools_dir
        elif legacy_tools_dir.exists():
            self.tools_dir = legacy_tools_dir
        elif package_install_tools.exists():
            self.tools_dir = package_install_tools
        else:
            # Fallback to the package install path so relative paths remain
            # stable even if tools are provisioned later during the run.
            self.tools_dir = package_install_tools
        python_paths = [str(self.root), str(package_source_root), str(package_dir)]
        if legacy_worker_dir.exists():
            python_paths.append(str(legacy_worker_dir))
        if legacy_tools_dir.exists():
            python_paths.append(str(legacy_tools_dir))
        if worker_tools_dir.exists():
            python_paths.append(str(worker_tools_dir))
        if package_install_tools.exists():
            python_paths.append(str(package_install_tools))
        if github_dir.exists():
            python_paths.append(str(github_dir))
        # Ensure the selected tools directory is always part of PYTHONPATH,
        # even if it does not yet exist on disk (for example in a clean clone
        # that only vendors the new package).
        python_paths.append(str(self.tools_dir))
        unique_python_paths = list(dict.fromkeys(python_paths))
        self.python_path = os.pathsep.join(unique_python_paths)
        self._fonts_ready = False

    # --- Git helpers -------------------------------------------------

    def clone_or_update_repo(
        self,
        repo_url: str,
        destination: Path,
        *,
        branch_name: str | None = None,
        force: bool = False,
    ) -> None:
        """Clone or update *repo_url* into *destination* using shared helpers."""
        git_utils.clone_or_update_repo(
            repo_url,
            destination,
            branch_name=branch_name,
            force=force,
        )

    def checkout_branch(self, repo_dir: Path, branch_name: str) -> None:
        """Checkout *branch_name* in *repo_dir* with fast-forward semantics."""
        git_utils.checkout_branch(repo_dir, branch_name)

    def remove_tree(self, path: Path) -> None:
        """Remove *path* recursively using the shared helper."""
        git_utils.remove_tree(path)

    def env(self, extra: Mapping[str, str] | None = None) -> MutableMapping[str, str]:
        env: MutableMapping[str, str] = os.environ.copy()
        env["PYTHONPATH"] = self.python_path
        # Ensure subprocesses log into the same directory as the orchestrator.
        # logging_config.get_log_directory() honours DOCKER_LOG_DIR with highest
        # priority, so we re-use it as a general log-dir override.
        env["DOCKER_LOG_DIR"] = str(self.config.logs_dir)
        if self.config.isolated:
            # Prevent user-site packages from affecting imports in local runs.
            # This keeps behaviour consistent across environments.
            env.setdefault("PYTHONNOUSERSITE", "1")
        if self.config.repository:
            env.setdefault("GITHUB_REPOSITORY", self.config.repository)
        env.setdefault("ORCHESTRATOR_PROFILE", self.config.profile.name)
        env.setdefault("ORCHESTRATOR_REPO_VISIBILITY", self.config.repo_visibility)
        if self.config.profile.env:
            env.update(self.config.profile.env)
        env.setdefault("GITBOOK_CONTENT_ID", self.config.language_id)
        env.setdefault("GITBOOK_CONTENT_ROOT", str(self.language_root))
        if self.config.content_config_path:
            env.setdefault(
                "GITBOOK_CONTENT_CONFIG", str(self.config.content_config_path)
            )
        if extra:
            env.update(extra)
        return env

    def run_command(
        self,
        cmd: Sequence[str],
        *,
        cwd: Path | None = None,
        env: Mapping[str, str] | None = None,
        check: bool = True,
    ) -> subprocess.CompletedProcess:
        display = " ".join(shlex.quote(part) for part in cmd)
        LOGGER.info("→ %s", display)
        if self.config.dry_run:
            LOGGER.info("Dry-run aktiv – Befehl wird übersprungen.")
            return subprocess.CompletedProcess(cmd, 0)
        result = subprocess.run(
            list(cmd),
            cwd=str(cwd or self.root),
            env=self.env(env),
            check=check,
            text=True,
        )
        return result

    def ensure_fonts(self) -> None:
        """Run font synchronisation once before publishing steps."""

        if self._fonts_ready:
            return

        cli_cmd = [
            self.python,
            "-m",
            "gitbook_worker.tools.publishing.fonts_cli",
            "sync",
            "--manifest",
            str(self.config.manifest),
            "--repo-root",
            str(self.root),
            "--search-path",
            str(self.root / ".github" / "fonts"),
        ]

        env = {"GITBOOK_WORKER_LOG_STDOUT_ONLY": "1"}
        LOGGER.info("Fonts werden synchronisiert ...")
        try:
            self.run_command(cli_cmd, env=env)
        except subprocess.CalledProcessError as exc:
            hint = _font_sync_hint(self.root, self.config.manifest)
            LOGGER.error(hint)
            print(hint, file=sys.stderr)
            raise FontSyncError("Font sync failed") from exc
        else:
            self._fonts_ready = True

    def git_last_commit_date(self, path: Path) -> str:
        try:
            result = subprocess.run(
                ["git", "log", "-1", "--format=%cs", str(path.relative_to(self.root))],
                cwd=str(self.root),
                capture_output=True,
                text=True,
                check=False,
            )
            value = (result.stdout or "").strip()
            return value or "1970-01-01"
        except Exception:
            return "1970-01-01"

    def get_frontmatter_loader(self) -> FrontMatterConfigLoader:
        """Lazy-load and cache the front matter configuration loader."""
        if self._frontmatter_loader is None:
            try:
                self._frontmatter_loader = FrontMatterConfigLoader()
            except FileNotFoundError:
                LOGGER.warning(
                    "Front matter configuration not found, using default (disabled)"
                )
                # Create a minimal default config
                from gitbook_worker.tools.publishing.frontmatter_config import (
                    FrontMatterConfig,
                    FrontMatterPatterns,
                )

                self._frontmatter_loader = type(
                    "DefaultFrontMatterConfigLoader",
                    (),
                    {
                        "config": FrontMatterConfig(
                            enabled=False,
                            patterns=FrontMatterPatterns(include=[], exclude=[]),
                            template={},
                        ),
                        "matches_patterns": lambda *args, **kwargs: False,
                        "merge_with_override": lambda override: self._frontmatter_loader.config,
                    },
                )()
        return self._frontmatter_loader

    def get_frontmatter_override(self) -> dict | None:
        """Extract frontmatter override from publish.yml manifest."""
        return self._manifest_data.get("frontmatter")

    def get_readme_loader(self) -> ReadmeConfigLoader:
        """Lazy-load and cache the README configuration loader."""
        if self._readme_loader is None:
            try:
                self._readme_loader = ReadmeConfigLoader(repo_root=self.root)
            except FileNotFoundError:
                LOGGER.warning(
                    "README configuration not found, using default (enabled)"
                )
                # Create a minimal default loader
                from gitbook_worker.tools.publishing.readme_config import (
                    ReadmeConfig,
                    ReadmePatterns,
                    ReadmeTemplate,
                    ReadmeLogging,
                )

                # Use a simple fallback configuration
                self._readme_loader = type(
                    "DefaultReadmeConfigLoader",
                    (),
                    {
                        "config": ReadmeConfig(
                            enabled=True,
                            patterns=ReadmePatterns(include=(), exclude=()),
                            template=ReadmeTemplate(
                                use_directory_name=True,
                                header_level=1,
                                footer="",
                            ),
                            readme_variants=("README.md", "readme.md", "Readme.md"),
                            logging=ReadmeLogging(
                                level="info",
                                log_skipped=False,
                                log_created=True,
                            ),
                        ),
                        "repo_root": self.root,
                        "matches_patterns": lambda *args, **kwargs: True,
                        "has_readme": lambda directory: False,
                        "generate_readme_content": lambda directory: f"# {directory.name}\n",
                        "merge_with_override": lambda override: self._readme_loader.config,
                    },
                )()
        return self._readme_loader

    def get_readme_override(self) -> dict | None:
        """Extract readme override from publish.yml manifest."""
        return self._manifest_data.get("readme")


def _as_bool(value: object, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        text = value.strip().lower()
        return text in {"1", "true", "yes", "on", "y"}
    return default


def _expand_template(value: object, variables: Mapping[str, str]) -> object:
    if isinstance(value, str):
        return Template(value).safe_substitute(variables)
    if isinstance(value, list):
        return type(value)(_expand_template(v, variables) for v in value)
    if isinstance(value, dict):
        return {k: _expand_template(v, variables) for k, v in value.items()}
    return value


def _load_manifest(path: Path) -> dict:
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return data


def _resolve_profile(
    manifest: dict,
    profile_name: str,
    variables: Mapping[str, str],
) -> OrchestratorProfile:
    profiles = manifest.get("profiles") or {}
    if not profiles:
        docker = DockerSettings(use_registry=False, image=None, cache=False)
        return OrchestratorProfile(
            name="default",
            steps=_DEFAULT_STEPS,
            docker=docker,
            description=None,
            env=None,
        )

    raw = profiles.get(profile_name)
    if raw is None:
        if profile_name != "default" and "default" not in profiles:
            available = ", ".join(sorted(profiles)) or "<none>"
            raise KeyError(
                f"Profil '{profile_name}' nicht gefunden. Verfügbare Profile: {available}"
            )
        LOGGER.warning(
            "Profil '%s' nicht gefunden – fallback auf 'default'", profile_name
        )
        raw = profiles.get("default")
        profile_name = "default"

    raw = _expand_template(raw or {}, variables)
    steps_raw = raw.get("steps")
    if not steps_raw:
        steps = _DEFAULT_STEPS
    else:
        steps = tuple(str(step).strip() for step in steps_raw if str(step).strip())

    docker_raw = raw.get("docker") or {}
    docker = DockerSettings(
        use_registry=_as_bool(docker_raw.get("use_registry")),
        image=str(docker_raw.get("image")) if docker_raw.get("image") else None,
        cache=_as_bool(docker_raw.get("cache")),
    )

    env = raw.get("env")
    if env and not isinstance(env, Mapping):
        raise TypeError("Profile 'env' erwartet ein Mapping")

    description = raw.get("description")
    if description is not None:
        description = str(description)

    return OrchestratorProfile(
        name=profile_name,
        steps=steps,
        docker=docker,
        description=description,
        env=env,
    )


def _detect_repo_visibility(explicit: str) -> str:
    if explicit != "auto":
        return explicit

    override = os.getenv("ORCHESTRATOR_REPO_VISIBILITY")
    if override:
        return override

    event_path = os.getenv("GITHUB_EVENT_PATH")
    if event_path and Path(event_path).is_file():
        try:
            payload = json.loads(Path(event_path).read_text(encoding="utf-8"))
            repo_info = payload.get("repository") or {}
            if repo_info.get("private"):
                return "private"
            return "public"
        except Exception:
            LOGGER.debug("Konnte GITHUB_EVENT_PATH nicht auswerten", exc_info=True)

    return "public"


def _resolve_paths(root: Path | None, manifest: Path | None) -> tuple[Path, Path]:
    repo_root = root.resolve() if root is not None else detect_repo_root(Path.cwd())
    try:
        manifest_path = resolve_manifest(
            explicit=manifest,
            cwd=Path.cwd(),
            repo_root=repo_root,
        )
    except SmartManifestError as exc:
        raise FileNotFoundError(str(exc)) from exc
    return repo_root, manifest_path


def _split_publisher_args(values: Iterable[str] | None) -> tuple[str, ...]:
    if not values:
        return ()
    result: list[str] = []
    for value in values:
        if not value:
            continue
        for part in shlex.split(value):
            result.append(part)
    return tuple(result)


def build_config(args: argparse.Namespace) -> OrchestratorConfig:
    root = (
        args.root.resolve() if args.root is not None else detect_repo_root(Path.cwd())
    )
    logs_dir = (
        args.logs_dir.resolve() if getattr(args, "logs_dir", None) else (root / "logs")
    )

    # Prefer repo-root content.yaml automatically unless the caller provided an
    # explicit --content-config.
    content_config = args.content_config
    if content_config is None:
        for candidate in (root / "content.yaml", root / "content.yml"):
            if candidate.exists():
                content_config = candidate
                break
    repository = args.repository or os.getenv("GITHUB_REPOSITORY")
    repository_template = repository.lower() if repository else ""
    variables = {
        "repo": repository_template,
        "profile": args.profile,
        "visibility": args.repo_visibility,
    }

    language_ctx = resolve_language_context(
        repo_root=root,
        language=args.language,
        manifest=args.manifest,
        content_config=content_config,
        allow_missing_config=True,
        allow_remote_entries=True,
        require_manifest=True,
        fetch_remote=True,
    )

    manifest = language_ctx.require_manifest()
    language_root = language_ctx.root
    language_id = language_ctx.language_id
    content_entry = language_ctx.entry
    if not language_root.exists():
        LOGGER.warning(
            "Language root '%s' (id=%s) does not exist yet",
            language_root,
            language_id,
        )

    manifest_data = _load_manifest(manifest)
    profile = _resolve_profile(manifest_data, args.profile, variables)
    repo_visibility = _detect_repo_visibility(args.repo_visibility)
    publisher_args = _split_publisher_args(getattr(args, "publisher_arg", None))
    raw_steps = getattr(args, "step", None)
    steps_override = tuple(raw_steps) if raw_steps else None
    return OrchestratorConfig(
        root=root,
        manifest=manifest,
        logs_dir=logs_dir,
        content_config_path=language_ctx.content_config_path,
        language_id=language_id,
        content_entry=content_entry,
        language_root=language_root,
        profile=profile,
        repo_visibility=repo_visibility,
        repository=repository,
        commit=getattr(args, "commit", None),
        base=getattr(args, "base", None),
        reset_others=getattr(args, "reset_others", False),
        publisher_args=publisher_args,
        dry_run=getattr(args, "dry_run", False),
        isolated=getattr(args, "isolated", False),
        no_gitbook_rename=getattr(args, "no_gitbook_rename", False),
        steps_override=steps_override,
        quality_profile=getattr(args, "quality_profile", "release"),
        quality_baseline=getattr(args, "quality_baseline", None),
        quality_accepted_findings=getattr(args, "quality_accepted_findings", None),
        quality_gate=getattr(args, "quality_gate", False),
        quality_scope=getattr(args, "quality_scope", "current"),
    )


def _log_analytics(
    ctx: RuntimeContext, entries: list[dict], level: int = logging.INFO
) -> None:
    payload = {
        "profile": ctx.config.profile.name,
        "manifest": str(ctx.config.manifest),
        "repository": ctx.config.repository or "<local>",
        "visibility": ctx.config.repo_visibility,
        "steps": entries,
    }
    LOGGER.log(
        level, "Orchestrator analytics: %s", json.dumps(payload, ensure_ascii=False)
    )


def run(config: OrchestratorConfig) -> None:
    # Load manifest data for access to frontmatter and other settings
    manifest_data = _load_manifest(config.manifest)
    ctx = RuntimeContext(config, manifest_data)
    steps = config.steps_override or config.profile.steps
    LOGGER.info(
        "Starte Orchestrator-Profil '%s' für Sprache '%s' (%s) mit Schritten: %s",
        config.profile.name,
        config.language_id,
        ctx.language_root,
        ", ".join(steps) or "<none>",
    )
    analytics: list[dict] = []
    for step in steps:
        handler = STEP_HANDLERS.get(step)
        if handler is None:
            raise KeyError(f"Unbekannter Schritt: {step}")
        started = _dt.datetime.now(_dt.timezone.utc)
        started_perf = time.perf_counter()
        LOGGER.info("Schritt '%s' starten", step)
        entry: dict[str, object] = {
            "step": step,
            "started": started.isoformat(),
        }
        if ctx.config.dry_run:
            LOGGER.info("Dry-run aktiviert – Schritt '%s' wird übersprungen", step)
            entry.update(
                {
                    "status": "skipped",
                    "duration_s": 0.0,
                }
            )
            analytics.append(entry)
            continue

        try:
            handler(ctx)
        except Exception as exc:
            entry.update(
                {
                    "status": "failed",
                    "duration_s": round(time.perf_counter() - started_perf, 3),
                    "error": repr(exc),
                }
            )
            analytics.append(entry)
            _log_analytics(ctx, analytics, level=logging.ERROR)
            raise
        else:
            entry.update(
                {
                    "status": "ok",
                    "duration_s": round(time.perf_counter() - started_perf, 3),
                }
            )
            analytics.append(entry)
    LOGGER.info("Orchestrator abgeschlossen")
    _log_analytics(ctx, analytics)


def validate_manifest(
    *,
    root: Path | None,
    manifest: Path | None,
    profile: str,
    all_profiles: bool,
    repo_visibility: str,
    repository: str | None,
) -> tuple[bool, list[str]]:
    errors: list[str] = []

    try:
        _resolved_root, manifest_path = _resolve_paths(root, manifest)
    except Exception as exc:  # pragma: no cover - defensive guard
        return False, [str(exc)]

    variables = {
        "repo": (repository or "").lower(),
        "profile": profile,
        "visibility": repo_visibility,
    }

    data = _load_manifest(manifest_path)
    profiles = data.get("profiles") or {}

    target_profiles = [profile]
    if all_profiles:
        target_profiles = list(profiles.keys()) or [profile]

    for name in target_profiles:
        try:
            resolved = _resolve_profile(data, name, variables)
        except Exception as exc:  # pragma: no cover - exercised via tests
            errors.append(f"Profil '{name}' ungültig: {exc}")
            continue

        unknown_steps = [
            step for step in resolved.steps if step not in STEP_HANDLERS.keys()
        ]
        if unknown_steps:
            errors.append(
                f"Profil '{name}' enthält unbekannte Schritte: "
                + ", ".join(sorted(set(unknown_steps)))
            )

    return (not errors), errors


def _step_check_if_to_publish(ctx: RuntimeContext) -> None:
    """Check which targets need to be published based on changed files.

    Uses smart_manage_publish_flags directly instead of deprecated wrapper.
    """
    LOGGER.info("Checking publish flags using smart_manage_publish_flags...")

    try:
        result = set_publish_flags(
            manifest_path=ctx.config.manifest,
            commit=ctx.config.commit or "HEAD",
            base=ctx.config.base,
            reset_others=ctx.config.reset_others,
            dry_run=False,
            debug=False,
        )

        if result["any_build_true"]:
            modified_count = len(result["modified_entries"])
            LOGGER.info("Found %d modified target(s) to publish", modified_count)
            for entry in result["modified_entries"]:
                LOGGER.info(
                    "  - %s: %s -> %s", entry["path"], entry["from"], entry["to"]
                )
        else:
            LOGGER.warning("No targets to publish - exiting")
            sys.exit(2)  # Exit code 2 = nothing to publish

    except Exception as exc:
        LOGGER.error("Failed to check publish flags: %s", exc, exc_info=True)
        raise


def _step_ensure_readme(ctx: RuntimeContext) -> None:
    """Ensure all directories have a README file.

    Uses smart configuration from readme.yml (with overrides from publish.yml).
    - Only creates README.md in directories without ANY readme variant
    - Case-insensitive check for existing READMEs
    - Respects include/exclude patterns from configuration
    - Never overwrites existing files

    Configuration hierarchy:
        1. publish.yml (readme: section) - highest priority
        2. readme.yml (project root)
        3. gitbook_worker/defaults/readme.yml - default
    """
    # Load README configuration
    readme_loader = ctx.get_readme_loader()

    # Merge with overrides from publish.yml
    override = ctx.get_readme_override()
    config = readme_loader.merge_with_override(override)

    # Check if README generation is enabled
    if not config.enabled:
        LOGGER.info("README auto-generation is disabled in configuration")
        return

    created: list[Path] = []
    skipped_existing: int = 0
    skipped_pattern: int = 0

    # Scope README generation to the language/content root so that code
    # directories (e.g. gitbook_worker/) are never touched.  See backlog #10.
    content_base = ctx.language_root
    LOGGER.info(
        "README generation scoped to language root: %s (repo root: %s)",
        content_base,
        ctx.root,
    )

    # Walk through directories in the language/content root only
    # Use iterdir + recursion to avoid expensive is_dir() checks on large repos
    def walk_dirs(base: Path) -> list[Path]:
        """Recursively collect directories, skipping hidden ones early."""
        dirs = []
        try:
            for item in base.iterdir():
                # Skip hidden items (starting with .) except content base
                if item.name.startswith(".") and item != content_base:
                    continue
                if item.is_dir():
                    dirs.append(item)
                    # Recurse into subdirectory
                    dirs.extend(walk_dirs(item))
        except (OSError, PermissionError):
            # Skip directories we can't read
            pass
        return dirs

    for directory in walk_dirs(content_base):
        # Skip content base directory itself
        if directory == content_base:
            continue

        rel = directory.relative_to(content_base)

        # Check pattern matching (smart exclude/include)
        if not readme_loader.matches_patterns(directory, content_base):
            skipped_pattern += 1
            if config.logging.log_skipped:
                LOGGER.debug("Skipped (pattern): %s", rel)
            continue

        # Check if directory already has a README (case-insensitive)
        if readme_loader.has_readme(directory):
            skipped_existing += 1
            if config.logging.log_skipped:
                LOGGER.debug("Skipped (has README): %s", rel)
            continue

        # Generate README content from template
        content = readme_loader.generate_readme_content(directory)
        target = directory / "README.md"

        # Final safety check: Don't overwrite if file somehow exists
        if target.exists():
            LOGGER.warning("SAFETY: Skipping %s - target exists unexpectedly", target)
            skipped_existing += 1
            continue

        created.append(target)

        # Dry-run mode: just log what would be done
        if ctx.config.dry_run:
            if config.logging.log_created:
                LOGGER.info("Would create: %s", rel / "README.md")
            continue

        # Create the README file
        try:
            target.write_text(content, encoding="utf-8")
            if config.logging.log_created:
                LOGGER.info("Created: %s", rel / "README.md")
        except OSError as exc:
            LOGGER.error("Failed to create %s: %s", target, exc)

    # Summary
    if created:
        LOGGER.info(
            "README generation: %d created, %d skipped (existing), %d skipped (pattern)",
            len(created),
            skipped_existing,
            skipped_pattern,
        )
    else:
        LOGGER.info(
            "README generation: No new READMEs needed (%d existing, %d excluded)",
            skipped_existing,
            skipped_pattern,
        )


def _step_update_citation(ctx: RuntimeContext) -> None:
    """Update CITATION.cff inside the language publish directory.

    Policy: All generated artifacts must stay within the configured publish
    directory; do not copy files into the repository root.
    """
    citation_publish = ctx.language_root / "publish" / "CITATION.cff"
    if not citation_publish.exists():
        LOGGER.info("Keine CITATION.cff gefunden – Schritt wird übersprungen")
        return
    today = _dt.datetime.now(tz=_dt.timezone.utc).date().isoformat()
    version_line = f"version: The_zenodo_release_on_{today}"
    date_line = f"date-released: '{today}'"
    text = citation_publish.read_text(encoding="utf-8").splitlines()
    changed = False
    for idx, line in enumerate(text):
        if line.startswith("version:") and line != version_line:
            text[idx] = version_line
            changed = True
        elif line.startswith("date-released:") and line != date_line:
            text[idx] = date_line
            changed = True
    if not changed:
        LOGGER.info("citation.cff ist bereits aktuell")
    else:
        LOGGER.info("Aktualisiere citation.cff auf %s", today)
    if ctx.config.dry_run:
        return

    # Write updated content to publish/CITATION.cff
    if changed:
        citation_publish.write_text("\n".join(text) + "\n", encoding="utf-8")

    LOGGER.info("CITATION.cff verbleibt im Publish-Verzeichnis: %s", citation_publish)


def _step_ai_reference_check(ctx: RuntimeContext) -> None:
    script = ctx.tools_dir / "quality" / "ai_references.py"
    if not script.exists():
        raise FileNotFoundError(
            f"ai_references.py nicht gefunden unter {script}; bitte Tools-Verzeichnis prüfen"
        )
    report = ctx.language_root / "publish" / "reports" / "ai_reference_report.json"
    summary = ctx.language_root / "content" / "SUMMARY.md"
    cmd = [
        ctx.python,
        str(script),
        "--root",
        str(ctx.root),
        "--manifest",
        str(ctx.config.manifest),
        "--language",
        str(ctx.language_id),
        "--json-report",
        str(report),
        "--no-progress",
    ]
    if summary.exists():
        cmd.extend(["--summary", str(summary)])
    ctx.run_command(cmd)


def _step_converter(ctx: RuntimeContext) -> None:
    dump_script = ctx.tools_dir / "publishing" / "dump_publish.py"
    convert_script = ctx.tools_dir / "converter" / "convert_assets.py"
    if not dump_script.exists() or not convert_script.exists():
        raise FileNotFoundError(
            "Konverter-Skripte nicht gefunden – bitte gitbook_worker/tools bereitstellen"
        )
    ctx.run_command(
        [
            ctx.python,
            "-m",
            "gitbook_worker.tools.publishing.dump_publish",
            "--root",
            str(ctx.root),
            "--manifest",
            str(ctx.config.manifest),
        ]
    )
    # Run the converter via fully qualified package path to avoid collisions with
    # user-local "tools" modules in neighbouring projects (Python prepends CWD).
    # Pass the manifest so paths are resolved from its parent directory.
    ctx.run_command(
        [
            ctx.python,
            "-m",
            "gitbook_worker.tools.converter.convert_assets",
            "--manifest",
            str(ctx.config.manifest),
        ]
    )


def _step_generate_attribution(ctx: RuntimeContext) -> None:
    """Generate font attribution files into publish out_dir(s).

    This step is a no-op unless at least one publish[] entry declares:

      generate_attribution: true

    The files are generated before the publisher runs so they can be referenced
    by the publishing pipeline (e.g. included in combined markdown).
    """

    publish_entries = ctx._manifest_data.get("publish")
    if not isinstance(publish_entries, list):
        LOGGER.info("No publish[] entries found; skipping attribution generation")
        return

    from gitbook_worker.tools.publishing.font_attribution import (
        generate_font_attribution_files,
    )

    manifest_dir = ctx.config.manifest.parent
    targets: List[Path] = []

    for entry in publish_entries:
        if not isinstance(entry, Mapping):
            continue
        if not _as_bool(entry.get("build"), default=False):
            continue
        if not _as_bool(entry.get("generate_attribution"), default=False):
            continue

        raw_out_dir = entry.get("out_dir")
        out_dir = Path(str(raw_out_dir)) if raw_out_dir else Path("publish")
        if not out_dir.is_absolute():
            out_dir = (manifest_dir / out_dir).resolve()
        targets.append(out_dir)

    unique_targets = list(dict.fromkeys(targets))
    if not unique_targets:
        LOGGER.info("No targets with generate_attribution=true; skipping")
        return

    for out_dir in unique_targets:
        generate_font_attribution_files(out_dir=out_dir)
        LOGGER.info("Generated font attribution in %s", out_dir)


def _format_yaml_value(value: object) -> str:
    """Format a Python value as a YAML-compatible string.

    Args:
        value: Python value (str, int, bool, list, dict, None)

    Returns:
        YAML-compatible string representation
    """
    if value is None:
        return "null"
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, list):
        if not value:
            return "[]"
        # Simple list formatting
        return "[" + ", ".join(_format_yaml_value(v) for v in value) + "]"
    if isinstance(value, dict):
        if not value:
            return "{}"
        # Simple dict formatting (not used in our templates typically)
        return str(value)
    # Default: string value
    if not isinstance(value, str):
        value = str(value)
    # Quote strings that contain special characters or are empty
    if not value or any(
        c in value
        for c in [
            ":",
            "#",
            "[",
            "]",
            "{",
            "}",
            ",",
            "&",
            "*",
            "!",
            "|",
            ">",
            "'",
            '"',
            "%",
            "@",
            "`",
        ]
    ):
        return f'"{value}"'
    return value


def _ensure_yaml_header(path: Path, template: dict, ctx: RuntimeContext) -> bool:
    """Ensure a markdown file has YAML front matter according to the template.

    Args:
        path: Path to the markdown file
        template: Front matter template dictionary
        ctx: Runtime context

    Returns:
        True if file was modified, False otherwise
    """
    lines = path.read_text(encoding="utf-8").splitlines()
    changed = False
    if not lines:
        lines = []

    # Replace {{date}} placeholder with actual git commit date
    resolved_template = {}
    for key, value in template.items():
        if isinstance(value, str) and value == "{{date}}":
            resolved_template[key] = ctx.git_last_commit_date(path)
        else:
            resolved_template[key] = value

    if not lines or lines[0].strip() != "---":
        # No front matter exists, create it
        header = ["---"]
        for key, value in resolved_template.items():
            header.append(f"{key}: {_format_yaml_value(value)}")
        header.extend(["---", ""])
        lines = header + lines
        changed = True
    else:
        # Front matter exists, check for missing fields
        end_idx = None
        for idx, line in enumerate(lines[1:], start=1):
            if line.strip() == "---":
                end_idx = idx
                break
        if end_idx is None:
            # No closing ---, add it
            lines.append("---")
            lines.append("")
            end_idx = len(lines) - 2
            changed = True

        header_lines = lines[1:end_idx]
        existing = {
            entry.split(":", 1)[0].strip() for entry in header_lines if ":" in entry
        }
        missing = [key for key in resolved_template.keys() if key not in existing]
        if missing:
            insert = [
                f"{key}: {_format_yaml_value(resolved_template[key])}"
                for key in missing
            ]
            lines = (
                [lines[0]]
                + header_lines
                + insert
                + [lines[end_idx]]
                + lines[end_idx + 1 :]
            )
            changed = True

    if changed and not ctx.config.dry_run:
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return changed


def _step_engineering_docs(ctx: RuntimeContext) -> None:
    """Apply front matter to markdown files according to configuration."""
    frontmatter_loader = ctx.get_frontmatter_loader()

    # Merge with per-publication overrides from publish.yml
    override = ctx.get_frontmatter_override()
    config = frontmatter_loader.merge_with_override(override)

    if not config.enabled:
        LOGGER.info("Front matter injection disabled in configuration")
        return

    if not config.template:
        LOGGER.warning("Front matter enabled but no template defined, skipping")
        return

    changed_files: list[Path] = []
    skipped_pattern: list[Path] = []

    for path in ctx.root.rglob("*.md"):
        rel = path.relative_to(ctx.root)

        # Skip directories that should always be excluded
        if any(part in _SKIP_DIRS for part in rel.parts):
            continue

        # Use smart pattern matching from configuration
        if not frontmatter_loader.matches_patterns(path, ctx.root):
            skipped_pattern.append(path)
            continue

        if _ensure_yaml_header(path, config.template, ctx):
            changed_files.append(path)

    if changed_files:
        LOGGER.info("YAML front matter updated for %d files", len(changed_files))
    else:
        LOGGER.info("All matching files already have valid front matter")

    if skipped_pattern:
        LOGGER.debug("Skipped %d files (pattern exclusion)", len(skipped_pattern))


def _step_publisher(ctx: RuntimeContext) -> None:
    pipeline = ctx.tools_dir / "publishing" / "pipeline.py"
    if not pipeline.exists():
        raise FileNotFoundError(
            f"pipeline.py nicht gefunden unter {pipeline}; bitte Tools-Verzeichnis bereitstellen"
        )

    try:
        ctx.ensure_fonts()
    except FontSyncError as exc:
        raise SystemExit(43) from exc

    cmd: list[str] = [
        ctx.python,
        str(pipeline),
        "--root",
        str(ctx.root),
        "--manifest",
        str(ctx.config.manifest),
    ]
    if ctx.config.no_gitbook_rename:
        cmd.append("--no-gitbook-rename")
    if ctx.config.dry_run:
        cmd.append("--dry-run")
    if ctx.config.commit:
        cmd.extend(["--commit", ctx.config.commit])
    if ctx.config.base:
        cmd.extend(["--base", ctx.config.base])
    if ctx.config.reset_others:
        cmd.append("--reset-others")
    for arg in ctx.config.publisher_args:
        cmd.extend(["--publisher-args", arg])
    try:
        ctx.run_command(cmd)
    except subprocess.CalledProcessError as exc:
        if exc.returncode == 43:
            hint = _font_sync_hint(ctx.root, ctx.config.manifest)
            LOGGER.error(hint)
            print(hint, file=sys.stderr)
            raise SystemExit(43) from exc
        raise


def _quality_content_build_enabled(entry: ContentEntry) -> bool:
    """Return whether a content entry participates in configured quality runs."""

    raw = entry.raw or {}
    return _as_bool(raw.get("build"), default=True)


def _configured_quality_language_ids(ctx: RuntimeContext) -> tuple[str, ...]:
    """Resolve buildable local content IDs for a configured quality run."""

    if not ctx.config.content_config_path:
        return (ctx.config.language_id,)
    try:
        content_config = load_content_config(
            ctx.config.content_config_path,
            cwd=ctx.root,
            repo_root=ctx.root,
            allow_missing=True,
        )
    except Exception as exc:  # pragma: no cover - defensive fallback
        LOGGER.warning(
            "Unable to load content config for configured quality scope: %s; "
            "falling back to current language %s",
            exc,
            ctx.config.language_id,
        )
        return (ctx.config.language_id,)

    language_ids: list[str] = []
    for entry in content_config.entries.values():
        if not entry.is_local:
            LOGGER.info(
                "Skipping content entry %s for configured quality scope: type=%s",
                entry.id,
                entry.type,
            )
            continue
        if not _quality_content_build_enabled(entry):
            LOGGER.info(
                "Skipping content entry %s for configured quality scope: build=false",
                entry.id,
            )
            continue
        try:
            language_root = entry.resolve_path(ctx.root)
        except ValueError as exc:
            LOGGER.info(
                "Skipping content entry %s for configured quality scope: %s",
                entry.id,
                exc,
            )
            continue
        if not language_root.exists():
            LOGGER.warning(
                "Skipping content entry %s for configured quality scope: root %s missing",
                entry.id,
                language_root,
            )
            continue
        language_ids.append(entry.id)

    if not language_ids:
        LOGGER.warning(
            "No buildable local content entries found for configured quality scope; "
            "falling back to current language %s",
            ctx.config.language_id,
        )
        return (ctx.config.language_id,)
    return tuple(dict.fromkeys(language_ids))


def _run_editorial_quality_bundle(
    ctx: RuntimeContext,
    *,
    quality_dir: Path,
    prefix: str,
    language_ids: Sequence[str],
    check_acceptance: bool,
) -> tuple[Path, int]:
    """Run metrics and acceptance for one language set."""

    metrics_report = quality_dir / f"{prefix}-editorial-metrics.json"
    findings_csv = quality_dir / f"{prefix}-editorial-findings.csv"
    findings_sarif = quality_dir / f"{prefix}-editorial-findings.sarif"
    dossier = quality_dir / f"{prefix}-editorial-acceptance.md"
    summary_json = quality_dir / f"{prefix}-editorial-acceptance.json"
    html_report = quality_dir / f"{prefix}-editorial-report.html"
    trend_jsonl = quality_dir / "editorial-trends.jsonl"
    snapshot_dir = quality_dir / "snapshots" / prefix

    language_args: list[str] = []
    for language_id in language_ids:
        language_args.extend(["--lang", str(language_id)])

    metrics_cmd: list[str] = [
        ctx.python,
        "-m",
        "gitbook_worker.tools.quality.editorial_metrics",
        "--root",
        str(ctx.root),
        "--profile",
        ctx.config.quality_profile,
        "--output",
        str(metrics_report),
        "--csv-output",
        str(findings_csv),
        "--sarif-output",
        str(findings_sarif),
        "--console-summary",
    ]
    metrics_cmd[5:5] = language_args
    if ctx.config.content_config_path:
        metrics_cmd.extend(["--content-config", str(ctx.config.content_config_path)])
    ctx.run_command(metrics_cmd)

    acceptance_cmd: list[str] = [
        ctx.python,
        "-m",
        "gitbook_worker.tools.quality.editorial_acceptance",
        str(metrics_report),
        "--profile",
        ctx.config.quality_profile,
        "--output",
        str(dossier),
        "--json-output",
        str(summary_json),
        "--html-output",
        str(html_report),
        "--trend-output",
        str(trend_jsonl),
        "--snapshot-dir",
        str(snapshot_dir),
        "--snapshot-root",
        str(ctx.root),
    ]
    if ctx.config.quality_baseline:
        acceptance_cmd.extend(["--baseline", str(ctx.config.quality_baseline)])
    if ctx.config.quality_accepted_findings:
        acceptance_cmd.extend(
            ["--accepted-findings", str(ctx.config.quality_accepted_findings)]
        )
    result = ctx.run_command(acceptance_cmd, check=check_acceptance)
    if result.returncode:
        LOGGER.warning(
            "Editorial quality acceptance finished with status %s; gate=%s, dossier=%s",
            result.returncode,
            ctx.config.quality_gate,
            dossier,
        )
    return dossier, int(result.returncode or 0)


def _step_editorial_quality(ctx: RuntimeContext) -> None:
    """Run editorial metrics and acceptance after a build."""

    quality_dir = ctx.config.logs_dir / "quality"
    quality_dir.mkdir(parents=True, exist_ok=True)

    if ctx.config.quality_scope == "configured":
        language_ids = _configured_quality_language_ids(ctx)
        LOGGER.info(
            "Running editorial quality for configured content entries: %s",
            ", ".join(language_ids),
        )
        failures: list[tuple[Path, int]] = []
        for language_id in language_ids:
            dossier, returncode = _run_editorial_quality_bundle(
                ctx,
                quality_dir=quality_dir,
                prefix=f"{language_id}-{ctx.config.quality_profile}",
                language_ids=(language_id,),
                check_acceptance=False,
            )
            if returncode:
                failures.append((dossier, returncode))

        project_dossier, project_returncode = _run_editorial_quality_bundle(
            ctx,
            quality_dir=quality_dir,
            prefix=f"project-{ctx.config.quality_profile}",
            language_ids=language_ids,
            check_acceptance=False,
        )
        if project_returncode:
            failures.append((project_dossier, project_returncode))

        if ctx.config.quality_gate and failures:
            first_dossier, first_returncode = failures[0]
            raise subprocess.CalledProcessError(
                first_returncode,
                ["editorial-quality", "--quality-scope", "configured"],
                output=f"first failing dossier: {first_dossier}",
            )
        return

    _run_editorial_quality_bundle(
        ctx,
        quality_dir=quality_dir,
        prefix=f"{ctx.config.language_id}-{ctx.config.quality_profile}",
        language_ids=(ctx.config.language_id,),
        check_acceptance=ctx.config.quality_gate,
    )


STEP_HANDLERS = {
    "check_if_to_publish": _step_check_if_to_publish,
    "ensure_readme": _step_ensure_readme,
    "update_citation": _step_update_citation,
    "ai-reference-check": _step_ai_reference_check,
    "converter": _step_converter,
    "engineering-document-formatter": _step_engineering_docs,
    "generate_attribution": _step_generate_attribution,
    "publisher": _step_publisher,
    "editorial-quality": _step_editorial_quality,
}


def _add_common_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--root", type=Path, help="Repository root")
    parser.add_argument(
        "--logs-dir",
        type=Path,
        help="Log-Verzeichnis (Standard: <root>/logs)",
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        help="Pfad zu publish.yml (Standard: --root/publish.yml)",
    )
    parser.add_argument(
        "--profile",
        default="default",
        help="Profilname aus publish.yml",
    )
    parser.add_argument(
        "--repo-visibility",
        choices=("auto", "public", "private"),
        default="auto",
        help="Sichtbarkeit des Repositories",
    )
    parser.add_argument(
        "--repository",
        help="Repository-Slug (owner/name) für Template-Substitution",
    )
    parser.add_argument(
        "--content-config",
        type=Path,
        help="Pfad zu content.yaml (Standard: erkennt <root>/content.yaml automatisch)",
    )
    parser.add_argument(
        "--lang",
        "--language",
        dest="language",
        help="Sprach-ID aus content.yaml (Standard: content.yaml.default)",
    )
    parser.add_argument(
        "--silent",
        "--quiet",
        dest="silent",
        action="store_true",
        help="Unterdrückt das Startup-Banner auf stdout (Logs bleiben aktiv)",
    )
    parser.add_argument(
        "--isolated",
        action="store_true",
        help="Isolierter Lauf: PYTHONNOUSERSITE=1 und kontrollierter PYTHONPATH für Subprozesse",
    )


def parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the ERDA workflow orchestrator",
    )
    add_exit_code_help(parser)
    subparsers = parser.add_subparsers(dest="command")

    run_parser = subparsers.add_parser("run", help="Orchestrator ausführen")
    _add_common_args(run_parser)
    run_parser.add_argument("--commit", help="Commit-SHA für Änderungsdetektion")
    run_parser.add_argument("--base", help="Basis-SHA für Änderungsdetektion")
    run_parser.add_argument(
        "--reset-others",
        action="store_true",
        help="Beim Setzen der Publish-Flags andere Einträge zurücksetzen",
    )
    run_parser.add_argument(
        "--publisher-arg",
        action="append",
        dest="publisher_arg",
        help="Zusätzliche Argumente für pipeline.py (mehrfach möglich)",
    )
    run_parser.add_argument(
        "--no-gitbook-rename",
        action="store_true",
        help="GitBook-Rename-Schritt überspringen (wird an pipeline.py weitergereicht)",
    )
    run_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Nur anzeigen, welche Schritte ausgeführt würden",
    )
    run_parser.add_argument(
        "--step",
        action="append",
        help="Überschreibt die im Profil definierten Schritte",
    )
    run_parser.add_argument(
        "--quality-profile",
        default="release",
        help="Editorial-Quality-Profil fuer den Schritt editorial-quality",
    )
    run_parser.add_argument(
        "--quality-baseline",
        type=Path,
        help="Vorheriger Editorial-Metrics-Report fuer Baseline-Vergleich",
    )
    run_parser.add_argument(
        "--quality-accepted-findings",
        type=Path,
        help="YAML/JSON Restrisiko-Register fuer editorial_acceptance",
    )
    run_parser.add_argument(
        "--quality-gate",
        action="store_true",
        help="Editorial-Acceptance-Status als CI-Gate verwenden",
    )
    run_parser.add_argument(
        "--quality-scope",
        choices=("current", "configured"),
        default="current",
        help=(
            "Umfang fuer editorial-quality: current erzeugt ein Dossier fuer --lang; "
            "configured erzeugt je buildbarer lokaler content.yaml-Version plus "
            "project-Gesamtdossier"
        ),
    )

    validate_parser = subparsers.add_parser(
        "validate", help="Manifest-Validierung ohne Pipeline-Lauf"
    )
    _add_common_args(validate_parser)
    validate_parser.add_argument(
        "--all-profiles",
        action="store_true",
        help="Alle Profile im Manifest prüfen statt nur --profile",
    )

    args = parser.parse_args(list(argv) if argv is not None else None)
    if args.command is None:
        args.command = "run"
    return args


def main(argv: Iterable[str] | None = None) -> None:
    args = parse_args(argv)
    handle_exit_code_help(args)

    _print_start_banner(getattr(args, "silent", False))
    config = build_config(args)
    reconfigure_root_logger(config.logs_dir)
    _log_start_context(args, config)
    if args.command == "validate":
        ok, errors = validate_manifest(
            root=config.root,
            manifest=config.manifest,
            profile=args.profile,
            all_profiles=args.all_profiles,
            repo_visibility=args.repo_visibility,
            repository=args.repository,
        )
        LOGGER.info(
            "validate | root=%s manifest=%s profile=%s all_profiles=%s",
            config.root,
            config.manifest,
            args.profile,
            args.all_profiles,
        )
        for err in errors:
            LOGGER.error(err)
        if not ok:
            LOGGER.error("Manifest-Validierung fehlgeschlagen")
            sys.exit(1)
        LOGGER.info("Manifest-Validierung erfolgreich")
        return

    _log_run_configuration(config)
    run(config)


__all__ = [
    "DockerSettings",
    "OrchestratorProfile",
    "OrchestratorConfig",
    "build_config",
    "validate_manifest",
    "parse_args",
    "run",
    "main",
]


if __name__ == "__main__":
    main()
