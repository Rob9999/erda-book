"""Central logging configuration for workflow tools."""

from __future__ import annotations

import importlib.util
import logging
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Optional


def _load_repo_local_gh_paths() -> Optional[Path]:
    """Load gh_paths.py located next to this checkout (if available)."""

    candidate = Path(__file__).resolve().parents[2] / ".github" / "gh_paths.py"
    if not candidate.exists():
        return None

    spec = importlib.util.spec_from_file_location(
        "_gitbook_worker_local_gh_paths", candidate
    )
    if not spec or not spec.loader:  # pragma: no cover - importlib edge case
        return None

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore[union-attr]
    gh_logs_dir = getattr(module, "GH_LOGS_DIR", None)
    return Path(gh_logs_dir) if gh_logs_dir else None


_LOCAL_GH_LOGS_DIR = _load_repo_local_gh_paths()

if _LOCAL_GH_LOGS_DIR is not None:
    GH_LOGS_DIR = _LOCAL_GH_LOGS_DIR
else:  # pragma: no cover - exercised outside repo checkouts
    try:
        from gitbook_worker.gh_paths import (  # type: ignore[attr-defined]
            GH_LOGS_DIR as _EXTERNAL_GH_LOGS_DIR,
        )
    except ModuleNotFoundError:  # pragma: no cover - fallback for local execution
        _EXTERNAL_GH_LOGS_DIR = Path(__file__).resolve().parent.parent / "logs"

    GH_LOGS_DIR = Path(_EXTERNAL_GH_LOGS_DIR)


def get_log_directory(override: Path | None = None) -> Path:
    """Determine the log directory based on environment.

    Priority:
    1. DOCKER_LOG_DIR env var (for external Docker log volumes)
    2. Explicit override provided by caller
    3. GH_LOGS_DIR (default: package or repo logs/)

    Returns:
        Path: Absolute path to the log directory.
    """
    import os

    docker_log_dir = os.environ.get("DOCKER_LOG_DIR")
    if docker_log_dir:
        log_path = Path(docker_log_dir)
        log_path.mkdir(parents=True, exist_ok=True)
        return log_path

    if override:
        override.mkdir(parents=True, exist_ok=True)
        return override

    return GH_LOGS_DIR


def _configure_root_logger(
    force: bool = False, log_dir_override: Path | None = None
) -> None:
    """Configure root logger with stdout/stderr handlers once.

    Args:
        force: Remove existing handlers and reconfigure even if already set.
        log_dir_override: Optional log directory to prefer when configuring.
    """
    import os

    root_logger = get_root_logger()
    if root_logger.handlers and not force:
        return

    if force and root_logger.handlers:
        for handler in list(root_logger.handlers):
            root_logger.removeHandler(handler)
            try:
                handler.close()
            except Exception:
                pass

    root_logger.setLevel(logging.INFO)
    formatter = get_standard_logger_formatter()

    stdout_only = os.environ.get("GITBOOK_WORKER_LOG_STDOUT_ONLY", "0") == "1"

    if stdout_only:
        print("[LOG] stdout (Docker build mode)")
        stdout_handler = logging.StreamHandler(sys.stdout)
        stdout_handler.setLevel(logging.INFO)
        stdout_handler.setFormatter(formatter)
        root_logger.addHandler(stdout_handler)
    else:
        log_dir = get_log_directory(log_dir_override)
        print(f"[LOG] {log_dir}")
        if log_dir:
            file_handler = logging.FileHandler(
                Path(log_dir) / "workflow.log", encoding="utf-8"
            )
            file_handler.setLevel(logging.INFO)
            file_handler.setFormatter(formatter)
            root_logger.addHandler(file_handler)
            stdout_handler = logging.StreamHandler(sys.stdout)
            stdout_handler.setLevel(logging.INFO)
            stdout_handler.setFormatter(formatter)
            root_logger.addHandler(stdout_handler)
            stderr_handler = logging.StreamHandler(sys.stderr)
            stderr_handler.setLevel(logging.WARNING)
            stderr_handler.setFormatter(formatter)
            root_logger.addHandler(stderr_handler)
        else:
            stdout_handler = logging.StreamHandler(sys.stdout)
            stdout_handler.setLevel(logging.INFO)
            stdout_handler.setFormatter(formatter)
            root_logger.addHandler(stdout_handler)

            stderr_handler = logging.StreamHandler(sys.stderr)
            stderr_handler.setLevel(logging.WARNING)
            stderr_handler.setFormatter(formatter)
            root_logger.addHandler(stderr_handler)


def get_root_logger() -> logging.Logger:
    """Get the root logger."""
    return logging.getLogger()


def get_standard_logger_formatter() -> logging.Formatter:
    """Return the default logger formatter.

    The formatter outputs log records in the format:
    YYYY-MM-DD-HH:MM:SS.mmm LEVEL MESSAGE

    Milliseconds are included after the seconds field for higher
    precision. Example:

        2025-09-12-14:35:42.123 INFO Processing started
    """
    return logging.Formatter(
        fmt="%(asctime)s.%(msecs)03d %(levelname)s %(message)s",
        datefmt="%Y-%m-%d-%H:%M:%S",
    )


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """Return a module-specific logger with default configuration."""
    _configure_root_logger()
    return logging.getLogger(name)


def reconfigure_root_logger(log_dir: Path) -> None:
    """Force root logger to use the given log directory."""

    global GH_LOGS_DIR
    GH_LOGS_DIR = Path(log_dir)
    _configure_root_logger(force=True, log_dir_override=GH_LOGS_DIR)


@contextmanager
def make_specific_logger(
    name: Optional[str], log_path: str, rootless: bool = False
) -> Iterator[logging.Logger]:
    """Context manager that yields a logger with a file handler attached.

    Args:
        name: Logger name (None for root logger).
        log_path: Path to the log file.
        rootless: If True, root logger and specific logger are logging separately;
                  Otherwise (default) the handler is attached to both the logger
                  and the root logger.

    Yields:
        logging.Logger: Configured logger instance.
    """
    handler = logging.FileHandler(log_path, encoding="utf-8")
    handler.setFormatter(get_standard_logger_formatter())

    logger = logging.getLogger(name)
    if not rootless:
        root_logger = get_root_logger()

    logger.setLevel(logging.INFO)

    logger.addHandler(handler)
    if not rootless:
        root_logger.addHandler(handler)
        root_logger.info(
            "================================START===================================="
        )
        root_logger.info("log:  %s", name)
        root_logger.info("path: %s", log_path)
        root_logger.info(
            "------------------------------------------------------------------------"
        )

    try:
        yield logger
    finally:
        logger.removeHandler(handler)
        if not rootless:
            root_logger.info(
                "================================END====================================="
            )
            root_logger.removeHandler(handler)
        handler.close()
