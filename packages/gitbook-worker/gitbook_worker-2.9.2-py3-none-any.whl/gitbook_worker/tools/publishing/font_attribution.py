from __future__ import annotations

import datetime as _dt
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import yaml

from gitbook_worker.tools.logging_config import get_logger

logger = get_logger(__name__)


@dataclass(frozen=True)
class FontAttributionEntry:
    key: str
    name: str
    version: str
    license: str
    license_url: str
    source_url: str | None
    usage_note: str | None
    copyright: str | None


@dataclass(frozen=True)
class AttributionResult:
    out_dir: Path
    attribution_path: Path
    license_paths: Tuple[Path, ...]


_CC_BY_4_URL_FRAGMENT = "creativecommons.org/licenses/by/4.0"
_DEJAVU_LICENSE_URL_FRAGMENT = "dejavu-fonts.github.io/license.html"


def _normalize_license_identifier(license_url: str, license_name: str) -> str:
    url = (license_url or "").strip().lower()
    if _CC_BY_4_URL_FRAGMENT in url:
        return "CC-BY-4.0"
    if _DEJAVU_LICENSE_URL_FRAGMENT in url:
        return "BITSTREAM-VERA"

    # Fallback: derive from license name
    candidate = re.sub(r"[^A-Za-z0-9]+", "-", (license_name or "UNKNOWN").strip())
    candidate = candidate.strip("-") or "UNKNOWN"
    return candidate.upper()


def _load_fonts_yaml(path: Path) -> Tuple[str, Mapping[str, Any]]:
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    version = str(data.get("version") or "1.0.0").strip() or "1.0.0"
    fonts = data.get("fonts")
    if not isinstance(fonts, Mapping):
        raise ValueError("fonts.yml missing required mapping key 'fonts'")
    return version, fonts


def _extract_license_texts_from_license_fonts(
    license_fonts_text: str,
) -> Dict[str, str]:
    """Extract known license sections from LICENSE-FONTS.

    This keeps the generator offline and makes outputs deterministic.

    Returns:
        Mapping from license identifier (e.g. CC-BY-4.0) to license text.
    """

    cc_start = license_fonts_text.find("Creative Commons Attribution 4.0 International")
    bit_start = license_fonts_text.find("Bitstream Vera License")

    result: Dict[str, str] = {}
    if cc_start != -1:
        cc_end = bit_start if bit_start != -1 else len(license_fonts_text)
        result["CC-BY-4.0"] = license_fonts_text[cc_start:cc_end].strip() + "\n"

    if bit_start != -1:
        result["BITSTREAM-VERA"] = license_fonts_text[bit_start:].strip() + "\n"

    return result


def _resolve_default_fonts_config(path: Path | None) -> Path:
    if path is not None:
        return path
    # Match FontConfigLoader search order.
    candidates = [
        Path("gitbook_worker/defaults/fonts.yml"),
        Path("defaults/fonts.yml"),
        Path("fonts.yml"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()

    # Fallback: resolve relative to this file.
    default_path = Path(__file__).resolve().parents[2] / "defaults" / "fonts.yml"
    if default_path.exists():
        return default_path

    raise FileNotFoundError("fonts.yml not found")


def _render_attribution_md(
    *,
    fonts: Sequence[FontAttributionEntry],
    fonts_yml_path: Path,
    fonts_yml_version: str,
    generated_at_utc: _dt.datetime,
    license_id_to_filename: Mapping[str, str],
) -> str:
    generated_iso = generated_at_utc.replace(microsecond=0).isoformat() + "Z"
    lines: List[str] = []
    lines.append("# Font Attribution")
    lines.append("")
    lines.append("This file is generated from the configured fonts registry.")
    lines.append("")
    lines.append(f"- Source: `{fonts_yml_path.as_posix()}`")
    lines.append(f"- Fonts config version: `{fonts_yml_version}`")
    lines.append(f"- Generated (UTC): `{generated_iso}`")
    lines.append("")
    lines.append("| Asset | Version | License | Copyright | Source | Notes |")
    lines.append("|---|---:|---|---|---|---|")

    for font in fonts:
        license_id = _normalize_license_identifier(font.license_url, font.license)
        license_file = license_id_to_filename.get(license_id)
        license_cell = font.license
        if license_file:
            license_cell = f"[{font.license}]({license_file})"

        copyright_cell = (font.copyright or "").replace("\n", " ").strip()
        source_cell = font.source_url or ""
        notes_cell = (font.usage_note or "").replace("\n", " ").strip()
        # Keep table stable and readable.
        lines.append(
            "| "
            + " | ".join(
                [
                    font.name,
                    font.version,
                    license_cell,
                    copyright_cell,
                    source_cell,
                    notes_cell,
                ]
            )
            + " |"
        )

    lines.append("")
    lines.append("---")
    lines.append("Generated by GitBook Worker.")
    lines.append("")
    return "\n".join(lines)


def generate_font_attribution_files(
    *,
    out_dir: Path,
    fonts_config_path: Path | None = None,
    license_fonts_path: Path | None = None,
) -> AttributionResult:
    """Generate ATTRIBUTION.md and LICENSE-* files for configured fonts.

    - Reads fonts metadata from fonts.yml (single source of truth).
    - Writes output files into out_dir.
    - License texts are extracted from LICENSE-FONTS (offline/deterministic).

    Raises:
        FileNotFoundError: if required inputs are missing.
        ValueError: if fonts.yml entries are incomplete.
    """

    out_dir = out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    fonts_yml = _resolve_default_fonts_config(fonts_config_path)
    fonts_version, fonts_mapping = _load_fonts_yaml(fonts_yml)

    license_fonts_path = (
        license_fonts_path.resolve()
        if license_fonts_path is not None
        else (Path(__file__).resolve().parents[3] / "LICENSE-FONTS")
    )
    if not license_fonts_path.exists():
        raise FileNotFoundError(f"LICENSE-FONTS not found at {license_fonts_path}")

    license_texts = _extract_license_texts_from_license_fonts(
        license_fonts_path.read_text(encoding="utf-8")
    )

    entries: List[FontAttributionEntry] = []
    required_fields = ("name", "license", "license_url")
    for key in sorted(fonts_mapping.keys(), key=lambda k: str(k).upper()):
        raw = fonts_mapping[key]
        if not isinstance(raw, Mapping):
            continue

        missing = [
            field for field in required_fields if not (raw.get(field) or "").strip()
        ]
        if missing:
            raise ValueError(
                f"fonts.yml entry '{key}' missing required fields: {', '.join(missing)}"
            )

        entries.append(
            FontAttributionEntry(
                key=str(key),
                name=str(raw.get("name") or "").strip(),
                version=str(raw.get("version") or "unknown").strip() or "unknown",
                license=str(raw.get("license") or "").strip(),
                license_url=str(raw.get("license_url") or "").strip(),
                source_url=(
                    str(raw.get("source_url")).strip()
                    if raw.get("source_url")
                    else None
                ),
                usage_note=(
                    str(raw.get("usage_note")).strip()
                    if raw.get("usage_note")
                    else None
                ),
                copyright=(
                    str(raw.get("copyright")).strip() if raw.get("copyright") else None
                ),
            )
        )

    # Determine which license files to write (dedup by identifier).
    license_id_to_filename: Dict[str, str] = {}
    license_id_to_text: Dict[str, str] = {}
    for entry in entries:
        license_id = _normalize_license_identifier(entry.license_url, entry.license)
        if license_id in license_id_to_filename:
            continue

        filename = f"LICENSE-{license_id}"
        license_id_to_filename[license_id] = filename

        text = license_texts.get(license_id)
        if text is None:
            raise ValueError(
                "Unsupported license for attribution generation: "
                f"{license_id} (license_url={entry.license_url})"
            )
        license_id_to_text[license_id] = text

    written_license_paths: List[Path] = []
    for license_id, filename in sorted(license_id_to_filename.items()):
        target = out_dir / filename
        target.write_text(license_id_to_text[license_id], encoding="utf-8")
        written_license_paths.append(target)

    attribution_path = out_dir / "ATTRIBUTION.md"
    attribution_md = _render_attribution_md(
        fonts=entries,
        fonts_yml_path=fonts_yml,
        fonts_yml_version=fonts_version,
        generated_at_utc=_dt.datetime.now(tz=_dt.timezone.utc),
        license_id_to_filename=license_id_to_filename,
    )
    attribution_path.write_text(attribution_md, encoding="utf-8")

    logger.info(
        "Generated font attribution in %s (%d fonts, %d license files)",
        out_dir,
        len(entries),
        len(written_license_paths),
    )

    return AttributionResult(
        out_dir=out_dir,
        attribution_path=attribution_path,
        license_paths=tuple(written_license_paths),
    )
