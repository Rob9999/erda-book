---
version: 1.2.0
date: 2026-05-05
history:
  - "1.2.0: 2026-05-05 — PDF-Font-/Emoji-Gate mit pdf_validator in lokale Release-Runs aufgenommen"
  - "1.1.0: 2026-02-08 — Docs-Update-Schritt, GitHub-Release-Schritt, annotated-Tag-Hinweis, Tag-Format modernisiert"
  - "1.0.0: 2026-01-10 — init: add release procedure"
---

# Release Procedure

This guide describes the release workflow for feature releases (e.g. `v2.2.0`) and hotfixes (e.g. `release-v.2.0.6-hotfix`). It follows the specifications defined in `AGENTS.md` and the established release process.

## Preparations

* Ensure the repository is clean, all intended changes are committed and pushed, and **either**:

  * you are performing the release from a release-candidate branch and will merge back into `main` afterwards, **or**
  * all other repository work is paused until the release is completed.
* Activate the Python environment (`.venv`) and ensure Pandoc/TeX/Docker are available.
* Fonts must be provided via `defaults/fonts.yml` (see `AGENTS.md`).

## Steps

1. **Create Release Notes and Update Release Version**

   * Create a new file in `docs/releases/` with front matter (`version`, `date`, `status`, `history`), structured according to `docs/releases/v2.0.5.md`.
   * Release version format:
     `release-v.<Major>.<Minor>.<Patch>[-hotfix|-<NAME>]`
   * Release short version format:
     `<Major>.<Minor>.<Patch>.[post1]`
   * Set the release short version in `setup.cfg`, e.g.
     `version = 2.0.6.post1`
   * Set the release short version in `gitbook_worker/__init__.py`, e.g.
     `__version__ = "2.0.6.post1"`

2. **Local Orchestrator Runs**

   * Edit content.yaml first if you need to test a specific case (e.g. customer-de or another target). 
   > ⚠️ Warning / Caution: Never commit or push customer content, or a content.yaml file that references customer content.
   * Run at least:
     `python -m gitbook_worker.tools.workflow_orchestrator run --root <repo> --content-config content.yaml --lang de --profile local`
     and
     `python -m gitbook_worker.tools.workflow_orchestrator run --root <repo> --content-config content.yaml --lang en --profile local`
   * Verify the TOC using the generated PDF path from `publish.yml`, for example:
     `python -m gitbook_worker.tools.utils.pdf_toc_extractor --pdf de/publish/das-sample-buch.pdf --format text`
     and
     `python -m gitbook_worker.tools.utils.pdf_toc_extractor --pdf en/publish/the-sample-book.pdf --format text`
   * Verify configured emoji/CJK font embedding and CJK text extraction:
     `python -m gitbook_worker.tools.testing.pdf_validator --pdf de/publish/das-sample-buch.pdf`
     and
     `python -m gitbook_worker.tools.testing.pdf_validator --pdf en/publish/the-sample-book.pdf`
   * If LaTeX debug logs are retained, include them in the gate to report missing-glyph signals. Directory inputs use the newest log set below that directory:
     `python -m gitbook_worker.tools.testing.pdf_validator --pdf de/publish/das-sample-buch.pdf --log de/publish/_latex-debug`
     Add `--fail-on-log-pattern` once the known baseline is clean or explicitly ratcheted.
   * Human verification: If a PDF was generated, open and review it manually to confirm quality and uncover any unknown issues.
   * Fix blockers, address simple bugs, or create a backlog entry in `gitbook_worker/docs/backlog/` → involve the PO.

3. **Docker-based Orchestrator Runs**

   * Run:
     `python -m gitbook_worker.tools.docker.run_docker orchestrator --use-dynamic --profile default --content-config content.yaml --lang customer-de --isolated --logs-dir logs/docker`
   * Human verification: If a PDF was generated, open and review it manually to confirm quality and uncover any unknown issues.
   * Fix blockers, address simple bugs, or create a backlog entry in `gitbook_worker/docs/backlog/` → involve the PO.

4. **Run Tests**

   * Execute:
     `python -m pytest gitbook_worker/tests -m "not slow" -q`
   * Fix blockers, address simple bugs, or create a backlog entry in `gitbook_worker/docs/backlog/` → involve the PO.

5. **Repeat Until Green**

   * Iterate steps 2–4 until all runs and tests complete without errors.
   * Fix blockers, address simple bugs, or create a backlog entry in `gitbook_worker/docs/backlog/` → involve the PO.

6. **Pip Install Smoke Test**

   * Build the package:
     `python -m build`
   * In a fresh virtual environment:
     `python -m venv .venv-smoke && .\.venv-smoke\Scripts\activate && pip install dist/gitbook_worker-<ver>-py3-none-any.whl`
   * Run:
     `python -m gitbook_worker.tools.workflow_orchestrator --help`
     (verify banner output and exit code 0), optionally perform a dry run.
   * Fix blockers, address simple bugs, or create a backlog entry in `gitbook_worker/docs/backlog/` → involve the PO.

7. **Repeat Until Green**

   * If issues occur, return to step 2 and repeat the process.

8. **Update User-Facing Documentation**

   Before tagging, ensure all user-facing docs reflect the new release:

   * **`README.md`** — version numbers in `pip install` examples, `publish.yml` code blocks, release history (DE + EN), development section.
   * **`docs/HANDBOOK.md`** — bump front-matter version; add/update sections covering new features.
   * **`docs/customer-installation.md`** — bump front-matter version; add configuration examples for new features.
   * **`docs/configuration-reference.md`** — add new keys, update status columns, bump front-matter version.
   * **`docs/releases/v<Major>.<Minor>.<Patch>.md`** — finalize release notes (features, file lists, test counts, known limitations).
   * Commit docs separately: `git commit -m "docs: <summary>"`.

9. **Tag & Push**

   * **Feature releases**: use SemVer tag, e.g. `v2.2.0`.
   * **Hotfixes**: use descriptive tag, e.g. `release-v.2.0.6-hotfix`.
   * Always use **annotated tags** (`-a`) with a message:
     ```bash
     git tag -a v2.2.0 -m "v2.2.0 Lueckenlos – short summary"
     git push origin main --tags
     ```
   * If the tag needs to be moved after a doc-only follow-up commit:
     ```bash
     git tag -f -a v2.2.0 -m "v2.2.0 Lueckenlos – updated"
     git push origin main --tags --force
     ```

10. **Publish GitHub Release**

    * Go to GitHub → Releases → "Draft a new release".
    * Select the tag created in step 9.
    * Title: `v<Major>.<Minor>.<Patch> "<Codename>"` (e.g. `v2.2.0 "Lückenlos"`).
    * Body: paste or link to `docs/releases/v<Major>.<Minor>.<Patch>.md`.
    * Attach build artifacts from `dist/`:
      * `gitbook_worker-<ver>-py3-none-any.whl`
      * `gitbook_worker-<ver>.tar.gz`
    * Publish the release.

## Documentation

* Record every deviation or blocker in the appropriate backlog entry (`gitbook_worker/docs/backlog/`).
* Example run log: `gitbook_worker/docs/release-preparation/release-run-2026-01-13-v2.1.0.md`.
* In the release notes, document tested commands, relevant fixes, and any remaining risks.

## Notes

* Do not use fonts outside of `fonts.yml`; the Docker setup pulls fonts exclusively from this file (see `Dockerfile.dynamic`).
* For LaTeX issues, set `ERDA_KEEP_LATEX_TEMP=1` and collect logs under `logs/`.
* Maintain SemVer consistency (`__version__` in `gitbook_worker/__init__.py` and packaging metadata).
* Prefer annotated tags over lightweight tags — they carry author, date, and message, which GitHub Releases and `git describe` rely on.