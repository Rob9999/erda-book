---
title: General PDF overflow hardening for URLs, tables, and code-like lines
version: 0.4.0
date: 2026-05-08
status: partial
priority: P2
labels: [pdf, layout, urls, tables, code]
history:
  - version: 0.4.0
    date: 2026-05-08
    description: Added content-width based paper selection for Markdown pipe tables and anonymized wide-table regression samples.
  - version: 0.3.1
    date: 2026-05-07
    description: Routed Pandoc token macro arguments through fvextra break insertion so URL-like code tokens wrap instead of clipping.
  - version: 0.3.0
    date: 2026-05-07
    description: Hardened fvextra code-fence wrapping for Pandoc token groups such as highlighted URL lines.
  - version: 0.2.1
    date: 2026-05-07
    description: Added DE/EN URL-in-code-fence stress samples for PDF wrapping investigation.
  - version: 0.2.0
    date: 2026-05-07
    description: Implemented global PDF code-fence wrapping via pdf_options.code_block_wrap; URLs and wide tables remain open.
  - version: 0.1.0
    date: 2026-05-07
    description: Initial anonymized P2 backlog for remaining non-CJK PDF overflows.
---

# General PDF Overflow Hardening for URLs, Tables, and Code-like Lines

## Problem

After the v2.4.2 CJK fix, a customer-side full PDF bounding-box scan still found
small non-CJK overflows. The worst cases were long URLs, wide tables, and
code/template-like lines. These are not regressions of the CJK fix, but they
remain relevant for print-quality PDFs.

## Impact

- Severity: P2.
- Affected content can exceed the right page boundary by a small amount.
- Typical causes are long unbreakable URL tokens, wide tabular content, and
  fixed-width/code-like strings.

## Desired Behavior

- Improve URL break behavior in the LaTeX/Pandoc PDF header, for example using
  `xurl` or stronger `url` break settings.
- Improve code/template line break behavior where safe.
- Provide strategy for wide Markdown tables:
  - table font-size tuning,
  - longtable configuration,
  - optional landscape/wide-table mode,
  - or preflight diagnostics that explain which table is too wide.
- Add a reusable PDF bounding-box layout scanner to release QA once stable.

## Implemented Slice

- `pdf_options.code_block_wrap` enables `fvextra`-based wrapping for Pandoc
  `Highlighting` and plain `verbatim` code environments.
- Highlighted Pandoc token macros such as `\NormalTok{...}` route their
  arguments through `fvextra` break insertion when supported, so URL-like code
  tokens can wrap inside the PDF text block.
- `breaknonspaceingroup=true` is enabled when the installed `fvextra` version
  supports it, and visible break-anywhere symbols are cleared to keep copied
  PDF text clean.
- Default is `true`; entries can opt out with `code_block_wrap: false`.
- DE/EN sample content now includes one semantically wrapped folded YAML scalar
  and one deliberately unwrapped long code-fence line as a regression sample.
- DE/EN sample content also includes one deliberately long URL inside a text
  code fence to study URL-token behavior without changing customer content.
- Markdown pipe tables now estimate per-column text width and select paper by
  usable text area after margins. The existing column-count heuristic remains
  as a lower bound, while long-cell 9-column tables can move beyond A4
  landscape when their measured content needs it.
- DE/EN sample content includes an anonymized 9-column wide-table regression
  case with long headers and long cells.

## Verification

- Synthetic URL fixture no longer exceeds page width.
- Synthetic wide-table fixture emits a controlled warning or uses an expected
  mitigation.
- Release QA can report line and block overflow counts with enough context for
  support triage.
