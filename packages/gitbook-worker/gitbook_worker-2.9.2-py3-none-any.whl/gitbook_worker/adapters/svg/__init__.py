"""SVG conversion adapters."""
