"""PDF-related adapter implementations."""
